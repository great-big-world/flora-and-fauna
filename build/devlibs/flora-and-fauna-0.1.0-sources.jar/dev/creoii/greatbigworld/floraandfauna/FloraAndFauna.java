package dev.creoii.greatbigworld.floraandfauna;

import dev.creoii.creoapi.api.modification.BlockModification;
import dev.creoii.greatbigworld.floraandfauna.registry.*;
import dev.creoii.greatbigworld.floraandfauna.season.SeasonManager;
import dev.creoii.greatbigworld.floraandfauna.world.feature.FallenTreeFeature;
import dev.creoii.greatbigworld.floraandfauna.world.feature.FallenTreeFeatureConfig;
import dev.creoii.greatbigworld.floraandfauna.world.feature.FreezeTopLayerFeature;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerWorldEvents;
import net.minecraft.block.Blocks;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;
import net.minecraft.world.gen.feature.DefaultFeatureConfig;
import net.minecraft.world.gen.feature.Feature;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class FloraAndFauna implements ModInitializer {
    public static final String NAMESPACE = "great_big_world";
    public static final Logger LOGGER = LogManager.getLogger(FloraAndFauna.class);
    public static final Feature<DefaultFeatureConfig> FREEZE_TOP_LAYER = new FreezeTopLayerFeature(DefaultFeatureConfig.CODEC);
    public static final Feature<FallenTreeFeatureConfig> FALLEN_TREE = new FallenTreeFeature(FallenTreeFeatureConfig.CODEC);

    @Override
    public void onInitialize() {
        FloraAndFaunaBlocks.register();
        FloraAndFaunaItems.register();
        FloraAndFaunaEntities.register();
        FloraAndFaunaSoundEvents.register();
        FloraAndFaunaTreeDecoratorTypes.register();
        FloraAndFaunaCommands.register();
        FloraAndFaunaGameRules.register();
        FloraAndFaunaCriteria.register();
        Registry.register(Registries.FEATURE, new Identifier(NAMESPACE, "freeze_top_layer"), FREEZE_TOP_LAYER);
        Registry.register(Registries.FEATURE, new Identifier(NAMESPACE, "fallen_tree"), FALLEN_TREE);
        ServerWorldEvents.LOAD.register((server, world) -> {
            SeasonManager seasonManager = SeasonManager.getInstance(server);
            seasonManager.setCurrentSeason(world, seasonManager.getCurrentSeason(), true);
        });
        ServerTickEvents.END_WORLD_TICK.register(world -> {
            SeasonManager.getInstance(world.getServer()).tick(world);
        });
        BlockModification.INSTANCE.setLuminance(Blocks.BROWN_MUSHROOM, 0);
    }
}
