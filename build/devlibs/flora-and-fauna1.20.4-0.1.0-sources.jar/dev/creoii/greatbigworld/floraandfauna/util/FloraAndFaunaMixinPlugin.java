package dev.creoii.greatbigworld.floraandfauna.util;

import com.google.common.collect.ImmutableList;
import dev.creoii.greatbigworld.floraandfauna.FloraAndFauna;
import net.fabricmc.loader.api.FabricLoader;
import org.objectweb.asm.tree.ClassNode;
import org.spongepowered.asm.mixin.extensibility.IMixinConfigPlugin;
import org.spongepowered.asm.mixin.extensibility.IMixinInfo;

import java.util.List;
import java.util.Set;

public class FloraAndFaunaMixinPlugin implements IMixinConfigPlugin {
    private static final boolean SODIUM_LOADED = FabricLoader.getInstance().isModLoaded("sodium");
    private static final List<String> SODIUM_DEPENDENT_MIXINS = new ImmutableList.Builder<String>()
            .add("dev.creoii.greatbigworld.floraandfauna.mixin.compat.ChunkBuilderMeshingTaskMixin")
            .add("dev.creoii.greatbigworld.floraandfauna.mixin.compat.DefaultColorProvidersMixin")
            .add("dev.creoii.greatbigworld.floraandfauna.mixin.compat.RenderSectionManagerAccessor")
            .add("dev.creoii.greatbigworld.floraandfauna.mixin.compat.RenderSectionManagerMixin")
            .add("dev.creoii.greatbigworld.floraandfauna.mixin.compat.SodiumWorldRendererAccessor")
            .build();

    @Override
    public void onLoad(String mixinPackage) {}

    @Override
    public String getRefMapperConfig() {
        return null;
    }

    @Override
    public boolean shouldApplyMixin(String targetClassName, String mixinClassName) {
        if (SODIUM_DEPENDENT_MIXINS.contains(mixinClassName)) {
            return SODIUM_LOADED;
        }
        return true;
    }

    @Override
    public void acceptTargets(Set<String> myTargets, Set<String> otherTargets) {}

    @Override
    public List<String> getMixins() {
        return null;
    }

    @Override
    public void preApply(String targetClassName, ClassNode targetClass, String mixinClassName, IMixinInfo mixinInfo) {}

    @Override
    public void postApply(String targetClassName, ClassNode targetClass, String mixinClassName, IMixinInfo mixinInfo) {}
}