package dev.creoii.greatbigworld.floraandfauna;

import dev.creoii.creoapi.api.modification.BlockModification;
import dev.creoii.greatbigworld.floraandfauna.registry.*;
import dev.creoii.greatbigworld.floraandfauna.season.SeasonManager;
import dev.creoii.greatbigworld.floraandfauna.world.feature.FallenTreeFeature;
import dev.creoii.greatbigworld.floraandfauna.world.feature.FallenTreeFeatureConfig;
import dev.creoii.greatbigworld.floraandfauna.world.feature.FreezeTopLayerFeature;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerWorldEvents;
import net.minecraft.class_2246;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3031;
import net.minecraft.class_3111;
import net.minecraft.class_7923;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class FloraAndFauna implements ModInitializer {
    public static final String NAMESPACE = "great_big_world";
    public static final Logger LOGGER = LogManager.getLogger(FloraAndFauna.class);
    public static final class_3031<class_3111> FREEZE_TOP_LAYER = new FreezeTopLayerFeature(class_3111.field_24893);
    public static final class_3031<FallenTreeFeatureConfig> FALLEN_TREE = new FallenTreeFeature(FallenTreeFeatureConfig.CODEC);

    @Override
    public void onInitialize() {
        FloraAndFaunaBlocks.register();
        FloraAndFaunaItems.register();
        FloraAndFaunaEntities.register();
        FloraAndFaunaSoundEvents.register();
        FloraAndFaunaTreeDecoratorTypes.register();
        FloraAndFaunaCommands.register();
        FloraAndFaunaGameRules.register();
        FloraAndFaunaCriteria.register();
        class_2378.method_10230(class_7923.field_41144, new class_2960(NAMESPACE, "freeze_top_layer"), FREEZE_TOP_LAYER);
        class_2378.method_10230(class_7923.field_41144, new class_2960(NAMESPACE, "fallen_tree"), FALLEN_TREE);
        ServerWorldEvents.LOAD.register((server, world) -> {
            SeasonManager seasonManager = SeasonManager.getInstance(server);
            seasonManager.setCurrentSeason(world, seasonManager.getCurrentSeason(), true);
        });
        ServerTickEvents.END_WORLD_TICK.register(world -> {
            SeasonManager.getInstance(world.method_8503()).tick(world);
        });
        BlockModification.INSTANCE.setLuminance(class_2246.field_10251, 0);
    }
}
