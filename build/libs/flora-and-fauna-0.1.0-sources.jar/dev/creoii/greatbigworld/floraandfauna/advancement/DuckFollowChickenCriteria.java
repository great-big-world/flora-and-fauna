package dev.creoii.greatbigworld.floraandfauna.advancement;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.Optional;
import java.util.function.Predicate;
import net.minecraft.class_2048;
import net.minecraft.class_3222;
import net.minecraft.class_4558;
import net.minecraft.class_5258;
import net.minecraft.class_5699;

public class DuckFollowChickenCriteria extends class_4558<DuckFollowChickenCriteria.Conditions> {
    public Codec<Conditions> method_54937() {
        return Conditions.CODEC;
    }

    @Override
    public void method_22510(class_3222 player, Predicate<Conditions> predicate) {
        super.method_22510(player, predicate);
    }

    public record Conditions(Optional<class_5258> player) implements class_4558.class_8788 {
        public static final Codec<Conditions> CODEC = RecordCodecBuilder.create((instance) -> {
            return instance.group(class_5699.method_53048(class_2048.field_47250, "player").forGetter(conditions -> {
                return conditions.player;
            })).apply(instance, Conditions::new);
        });
    }
}
