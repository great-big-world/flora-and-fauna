package dev.creoii.greatbigworld.floraandfauna.block;

import com.mojang.serialization.MapCodec;
import dev.creoii.greatbigworld.floraandfauna.util.FloraAndFaunaTags;
import net.minecraft.block.*;
import net.minecraft.class_1297;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2261;
import net.minecraft.class_2338;
import net.minecraft.class_2386;
import net.minecraft.class_243;
import net.minecraft.class_259;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2758;
import net.minecraft.class_3218;
import net.minecraft.class_3610;
import net.minecraft.class_3612;
import net.minecraft.class_3726;
import net.minecraft.class_5819;

public class AlgaeBlock extends class_2261 {
    public static final class_2758 DENSITY = class_2758.method_11867("density", 1, 3);
    public static final MapCodec<AlgaeBlock> CODEC = AlgaeBlock.method_54094(AlgaeBlock::new);
    public static final class_265 SHAPE = class_2248.method_9541(0d, 0d, 0d, 16d, 1.5d, 16d);

    public AlgaeBlock(class_2251 settings) {
        super(settings);
        method_9590(method_9595().method_11664().method_11657(DENSITY, 3));
    }

    @Override
    protected MapCodec<? extends class_2261> method_53969() {
        return field_46280;
    }

    @Override
    @SuppressWarnings("deprecation")
    public void method_9548(class_2680 state, class_1937 world, class_2338 pos, class_1297 entity) {
        if (entity.method_5864().method_20210(FloraAndFaunaTags.IGNORES_ALGAE))
            return;
        int density = state.method_11654(DENSITY);
        if (density == 2) {
            entity.method_5844(state, new class_243(.75d, .95d, .75d));
            world.method_8652(pos, state.method_11657(DENSITY, 1), 3);
        } else if (density == 3) {
            entity.method_5844(state, new class_243(.5d, .75d, .5d));
            world.method_8652(pos, state.method_11657(DENSITY, 2), 3);
        }
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(DENSITY);
    }

    @Override
    @SuppressWarnings("deprecation")
    public class_265 method_9530(class_2680 state, class_1922 world, class_2338 pos, class_3726 context) {
        return SHAPE;
    }

    @Override
    @SuppressWarnings("deprecation")
    public class_265 method_9549(class_2680 state, class_1922 world, class_2338 pos, class_3726 context) {
        return class_259.method_1073();
    }

    @Override
    public boolean method_9542(class_2680 state) {
        return state.method_11654(DENSITY) < 3;
    }

    @Override
    @SuppressWarnings("deprecation")
    public void method_9514(class_2680 state, class_3218 world, class_2338 pos, class_5819 random) {
        int density = state.method_11654(DENSITY);
        if (density == 2) {
            world.method_8501(pos, state.method_11657(DENSITY, 3));
        } else if (density == 1) {
            world.method_8501(pos, state.method_11657(DENSITY, 2));
        }
    }

    @Override
    protected boolean method_9695(class_2680 floor, class_1922 world, class_2338 pos) {
        class_3610 fluidState = world.method_8316(pos);
        class_3610 fluidState2 = world.method_8316(pos.method_10084());
        return (fluidState.method_15772() == class_3612.field_15910 || floor.method_26204() instanceof class_2386) && fluidState2.method_15772() == class_3612.field_15906;
    }
}
