package dev.creoii.greatbigworld.floraandfauna.block;

import net.minecraft.block.*;
import net.minecraft.class_1750;
import net.minecraft.class_1922;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2465;
import net.minecraft.class_259;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_2746;
import net.minecraft.class_3610;
import net.minecraft.class_3612;
import net.minecraft.class_3726;
import net.minecraft.class_3737;

public class HollowLogBlock extends class_2465 implements class_3737 {
    private static final class_265 X_SHAPE = class_259.method_17786(class_2248.method_9541(0d, 0d, 0d, 16d, 16d, 3d), class_2248.method_9541(0d, 13d, 0d, 16d, 16d, 16d), class_2248.method_9541(0d, 0d, 13d, 16d, 16d, 16d), class_2248.method_9541(0d, 0d, 0d, 16d, 3d, 16d));
    private static final class_265 Y_SHAPE = class_259.method_17786(class_2248.method_9541(0d, 0d, 0d, 16d, 16d, 3d), class_2248.method_9541(0d, 0d, 0d, 3d, 16d, 16d), class_2248.method_9541(0d, 0d, 13d, 16d, 16d, 16d), class_2248.method_9541(13d, 0d, 0d, 16d, 16d, 16d));
    private static final class_265 Z_SHAPE = class_259.method_17786(class_2248.method_9541(13d, 0d, 0d, 16d, 16d, 16d), class_2248.method_9541(0d, 0d, 0d, 3d, 16d, 16d), class_2248.method_9541(0d, 13d, 0d, 16d, 16d, 16d), class_2248.method_9541(0d, 0d, 0d, 16d, 3d, 16d));
    private static final class_265 X_COLLISION_SHAPE = class_259.method_17786(class_2248.method_9541(0d, 0d, 0d, 16d, 16d, 2.25d), class_2248.method_9541(0d, 13.75d, 0d, 16d, 16d, 16d), class_2248.method_9541(0d, 0d, 13d, 16d, 16d, 16d), class_2248.method_9541(0d, 0d, 0d, 16d, 2.25d, 16d));
    private static final class_265 Y_COLLISION_SHAPE = class_259.method_17786(class_2248.method_9541(0d, 0d, 0d, 16d, 16d, 2.25d), class_2248.method_9541(0d, 0d, 0d, 2.25d, 16d, 16d), class_2248.method_9541(0d, 0d, 13.75d, 16d, 16d, 16d), class_2248.method_9541(13.75d, 0d, 0d, 16d, 16d, 16d));
    private static final class_265 Z_COLLISION_SHAPE = class_259.method_17786(class_2248.method_9541(13.75d, 0d, 0d, 16d, 16d, 16d), class_2248.method_9541(0d, 0d, 0d, 2.25d, 16d, 16d), class_2248.method_9541(0d, 13.75d, 0d, 16d, 16d, 16d), class_2248.method_9541(0d, 0d, 0d, 16d, 2.25d, 16d));
    private static final class_2746 WATERLOGGED = class_2741.field_12508;

    public HollowLogBlock(class_2251 settings) {
        super(settings);
        method_9590(method_9595().method_11664().method_11657(field_11459, class_2350.class_2351.field_11052).method_11657(WATERLOGGED, false));
    }

    @Override
    @SuppressWarnings("deprecation")
    public class_265 method_9530(class_2680 state, class_1922 world, class_2338 pos, class_3726 context) {
        return switch (state.method_11654(field_11459)) {
            case field_11048 -> X_SHAPE;
            case field_11052 -> Y_SHAPE;
            case field_11051 -> Z_SHAPE;
        };
    }

    @Override
    @SuppressWarnings("deprecation")
    public class_265 method_9549(class_2680 state, class_1922 world, class_2338 pos, class_3726 context) {
        return switch (state.method_11654(field_11459)) {
            case field_11048 -> X_COLLISION_SHAPE;
            case field_11052 -> Y_COLLISION_SHAPE;
            case field_11051 -> Z_COLLISION_SHAPE;
        };
    }

    @Override
    @SuppressWarnings("deprecation")
    public class_265 method_9584(class_2680 state, class_1922 world, class_2338 pos) {
        return class_259.method_1077();
    }

    @Override
    @SuppressWarnings("deprecation")
    public class_3610 method_9545(class_2680 state) {
        return state.method_11654(WATERLOGGED) ? class_3612.field_15910.method_15729(false) : super.method_9545(state);
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(field_11459, WATERLOGGED);
    }

    @Override
    public class_2680 method_9605(class_1750 ctx) {
        return method_9564().method_11657(field_11459, ctx.method_8038().method_10166()).method_11657(WATERLOGGED, ctx.method_8045().method_8316(ctx.method_8037()).method_39360(class_3612.field_15910));
    }
}
