package dev.creoii.greatbigworld.floraandfauna.block;

import com.mojang.serialization.MapCodec;
import dev.creoii.greatbigworld.floraandfauna.client.FloraAndFaunaClient;
import dev.creoii.greatbigworld.floraandfauna.season.Season;
import dev.creoii.greatbigworld.floraandfauna.util.FloraAndFaunaTags;
import dev.creoii.greatbigworld.floraandfauna.util.SnowyHelper;
import net.minecraft.block.*;
import net.minecraft.class_10;
import net.minecraft.class_1750;
import net.minecraft.class_1802;
import net.minecraft.class_1922;
import net.minecraft.class_1944;
import net.minecraft.class_1959;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2488;
import net.minecraft.class_259;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_3218;
import net.minecraft.class_3726;
import net.minecraft.class_5778;
import net.minecraft.class_5819;
import net.minecraft.class_6880;
import net.minecraft.class_7118;
import org.jetbrains.annotations.Nullable;

public class MossCarpetBlock extends class_5778 {
    public static final MapCodec<MossCarpetBlock> CODEC = method_54094(MossCarpetBlock::new);
    private final class_7118 grower = new class_7118(this);

    public MossCarpetBlock(class_2251 settings) {
        super(settings);
        method_9590(method_9595().method_11664().method_11657(class_2741.field_12489, false).method_11657(class_2741.field_12540, false).method_11657(class_2741.field_12487, false).method_11657(class_2741.field_12527, false).method_11657(class_2741.field_12519, false).method_11657(class_2741.field_12546, false).method_11657(SnowyHelper.SNOW_LAYERS, 0));
    }

    @Override
    public class_265 method_9530(class_2680 state, class_1922 world, class_2338 pos, class_3726 context) {
        class_265 shape = super.method_9530(state, world, pos, context);
        if (SnowyHelper.isSnowy(state)) {
            return class_259.method_1084(shape, SnowyHelper.LAYERS_TO_SHAPE[state.method_11654(SnowyHelper.SNOW_LAYERS) - 1]);
        }
        return shape;
    }

    @Override
    public boolean method_9542(class_2680 state) {
        return SnowyHelper.isSnowy(state);
    }

    @SuppressWarnings("deprecation")
    public void method_9514(class_2680 state, class_3218 world, class_2338 pos, class_5819 random) {
        class_6880<class_1959> biomeEntry = world.method_23753(pos);
        if (world.method_8314(class_1944.field_9282, pos) > 11 || (FloraAndFaunaClient.getCurrentSeason() != Season.WINTER && !biomeEntry.method_40220(FloraAndFaunaTags.NOT_AFFECTED_BY_WINTER) && biomeEntry.comp_349().method_39927(pos))) {
            if (state.method_11654(SnowyHelper.SNOW_LAYERS) > 0)
                method_9497(class_2246.field_10477.method_9564().method_11657(class_2488.field_11518, state.method_11654(SnowyHelper.SNOW_LAYERS)), world, pos);
            world.method_8501(pos, state.method_11657(SnowyHelper.SNOW_LAYERS, 0));
        }
    }

    @Override
    public boolean method_9616(class_2680 state, class_1750 context) {
        if (super.method_9616(state, context))
            return true;
        return context.method_8041().method_31574(class_1802.field_8749);
    }

    @SuppressWarnings("deprecation")
    public boolean method_9516(class_2680 state, class_1922 world, class_2338 pos, class_10 type) {
        if (type == class_10.field_50)
            return state.method_11654(SnowyHelper.SNOW_LAYERS) < 5;
        return false;
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        super.method_9515(builder);
        builder.method_11667(SnowyHelper.SNOW_LAYERS);
    }

    @Nullable
    @Override
    public class_2680 method_9605(class_1750 ctx) {
        class_2680 placementState = super.method_9605(ctx);
        class_2680 state = ctx.method_8045().method_8320(ctx.method_8037());
        if (placementState != null && state.method_26204() instanceof class_2488) {
            return placementState.method_11657(SnowyHelper.SNOW_LAYERS, state.method_11654(class_2741.field_12536));
        }
        return placementState;
    }

    @Override
    protected MapCodec<? extends class_5778> method_53969() {
        return field_46280;
    }

    @Override
    public class_7118 method_41432() {
        return grower;
    }
}
