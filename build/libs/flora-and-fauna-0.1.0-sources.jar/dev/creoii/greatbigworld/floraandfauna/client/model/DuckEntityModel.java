package dev.creoii.greatbigworld.floraandfauna.client.model;

import com.google.common.collect.ImmutableList;
import dev.creoii.greatbigworld.floraandfauna.entity.DuckEntity;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_243;
import net.minecraft.class_3532;
import net.minecraft.class_4592;
import net.minecraft.class_5603;
import net.minecraft.class_5606;
import net.minecraft.class_5607;
import net.minecraft.class_5609;
import net.minecraft.class_5610;
import net.minecraft.class_630;
import net.minecraft.client.model.*;

@Environment(EnvType.CLIENT)
public class DuckEntityModel extends class_4592<DuckEntity> {
    private final class_630 head;
    private final class_630 bill;
    private final class_630 body;
    private final class_630 leftWing;
    private final class_630 rightWing;
    private final class_630 leftLeg;
    private final class_630 rightLeg;

    public DuckEntityModel(class_630 root) {
        super(false, 4.9f, 2f);
        head = root.method_32086("head");
        bill = root.method_32086("bill");
        body = root.method_32086("body");
        leftWing = root.method_32086("left_wing");
        rightWing = root.method_32086("right_wing");
        leftLeg = root.method_32086("left_leg");
        rightLeg = root.method_32086("right_leg");
    }

    public static class_5607 getTexturedModelData() {
        class_5609 modelData = new class_5609();
        class_5610 modelPartData = modelData.method_32111();
                                                                                                                                                                // here
        class_5610 head = modelPartData.method_32117("head", class_5606.method_32108().method_32101(14, 14).method_32097(-2.0F, -6.0F, -1.0F, 4.0F, 6.0F, 3.0F), class_5603.method_32090(0.0F, 15.0F, -4.0F));
        class_5610 bill = modelPartData.method_32117("bill", class_5606.method_32108().method_32101(18, 0).method_32097(-2.0F, -4.0F, -4.0F, 4.0F, 2.0F, 3.0F), class_5603.method_32090(0.0F, 15.0F, -4.0F));
        class_5610 body = modelPartData.method_32117("body", class_5606.method_32108().method_32101(0, 0).method_32097(-3.0F, -4.0F, -4.0F, 6.0F, 8.0F, 6.0F), class_5603.method_32091(0.0F, 16.0F, 0.0F, 1.5708F, 0.0F, 0.0f));

        class_5610 leftWing = modelPartData.method_32117("left_wing", class_5606.method_32108().method_32101(0, 14).method_32097(-1.0F, 1.0F, -3.0F, 1.0F, 4.0F, 6.0F), class_5603.method_32090(3.5F, 14.0F, 0.0F));
        class_5610 rightWing = modelPartData.method_32117("right_wing", class_5606.method_32108().method_32101(0, 14).method_32097(0.0F, 1.0F, -3.0F, 1.0F, 4.0F, 6.0F), class_5603.method_32090(-3.5F, 14.0F, 0.0F));

        class_5610 leftLeg = modelPartData.method_32117("left_leg", class_5606.method_32108().method_32101(11, 23).method_32097(-1.0F, 1.0F, -3.0F, 3.0F, 4.0F, 3.0F), class_5603.method_32090(1.5F, 20.0F, 1.0F));
        class_5610 rightLeg = modelPartData.method_32117("right_leg", class_5606.method_32108().method_32101(11, 23).method_32097(-1.0F, 1.0F, -3.0F, 3.0F, 4.0F, 3.0F), class_5603.method_32090(-1.5F, 20.0F, 1.0F));

        return class_5607.method_32110(modelData, 32, 32);
    }

    @Override
    public void animateModel(DuckEntity entity, float limbAngle, float limbDistance, float tickDelta) {
    }

    @Override
    public void setAngles(DuckEntity entity, float limbAngle, float limbDistance, float animationProgress, float headYaw, float headPitch) {
        head.field_3654 = headPitch * ((float) Math.PI / 180f);
        head.field_3675 = headYaw * ((float) Math.PI / 180f);
        bill.field_3654 = head.field_3654;
        bill.field_3675 = head.field_3675;
        rightLeg.field_3654 = class_3532.method_15362(limbAngle * .6662f) * 1.4f * limbDistance;
        leftLeg.field_3654 = class_3532.method_15362(limbAngle * .6662f + (float) Math.PI) * 1.4f * limbDistance;
        if (!entity.method_5799()) {
            rightWing.field_3674 = animationProgress;
            leftWing.field_3674 = -animationProgress;

            leftLeg.field_3665 = true;
            rightLeg.field_3665 = true;
        } else {
            rightWing.field_3674 *= .05f;
            leftWing.field_3674 *= .05f;

            if (!entity.method_18798().equals(class_243.field_1353) || entity.method_5962().method_6241()) {
                leftLeg.field_3665 = false;
                rightLeg.field_3665 = false;

                if (!entity.method_5988().method_38970()) {
                    float bob = class_3532.method_15374(entity.field_6012 * .4f) * .1f;
                    head.field_3654 = bob * 1.75f + .3334f;
                    bill.field_3654 = head.field_3654;
                }
            }
        }
    }

    @Override
    protected Iterable<class_630> method_22946() {
        return ImmutableList.of(head, bill);
    }

    @Override
    protected Iterable<class_630> method_22948() {
        return ImmutableList.of(body, rightLeg, leftLeg, rightWing, leftWing);
    }
}
