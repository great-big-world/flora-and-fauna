package dev.creoii.greatbigworld.floraandfauna.client.render;

import dev.creoii.greatbigworld.floraandfauna.FloraAndFauna;
import dev.creoii.greatbigworld.floraandfauna.client.model.DuckEntityModel;
import dev.creoii.greatbigworld.floraandfauna.entity.DuckEntity;
import dev.creoii.greatbigworld.floraandfauna.util.FloraAndFaunaEntityModelLayers;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2960;
import net.minecraft.class_3532;
import net.minecraft.class_5617;
import net.minecraft.class_927;

@Environment(EnvType.CLIENT)
public class DuckEntityRenderer extends class_927<DuckEntity, DuckEntityModel> {
    private static final class_2960 TEXTURE = new class_2960(FloraAndFauna.NAMESPACE, "textures/entity/duck.png");

    public DuckEntityRenderer(class_5617.class_5618 context) {
        super(context, new DuckEntityModel(context.method_32167(FloraAndFaunaEntityModelLayers.DUCK)), .3f);
    }

    public class_2960 getTexture(DuckEntity duckEntity) {
        return TEXTURE;
    }

    protected float getAnimationProgress(DuckEntity duckEntity, float f) {
        float g = class_3532.method_16439(f, duckEntity.prevFlapProgress, duckEntity.flapProgress);
        float h = class_3532.method_16439(f, duckEntity.prevMaxWingDeviation, duckEntity.maxWingDeviation);
        return (class_3532.method_15374(g) + 1) * h;
    }
}
