package dev.creoii.greatbigworld.floraandfauna.entity;

import dev.creoii.greatbigworld.floraandfauna.entity.goal.DuckCaravanGoal;
import dev.creoii.greatbigworld.floraandfauna.entity.goal.WanderAroundFarInWaterGoal;
import dev.creoii.greatbigworld.floraandfauna.registry.FloraAndFaunaEntities;
import dev.creoii.greatbigworld.floraandfauna.registry.FloraAndFaunaSoundEvents;
import net.minecraft.class_1266;
import net.minecraft.class_1282;
import net.minecraft.class_1296;
import net.minecraft.class_1299;
import net.minecraft.class_1308;
import net.minecraft.class_1309;
import net.minecraft.class_1313;
import net.minecraft.class_1315;
import net.minecraft.class_1341;
import net.minecraft.class_1347;
import net.minecraft.class_1361;
import net.minecraft.class_1374;
import net.minecraft.class_1376;
import net.minecraft.class_1391;
import net.minecraft.class_1408;
import net.minecraft.class_1429;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1856;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2680;
import net.minecraft.class_2940;
import net.minecraft.class_2943;
import net.minecraft.class_2945;
import net.minecraft.class_3218;
import net.minecraft.class_3414;
import net.minecraft.class_3417;
import net.minecraft.class_3532;
import net.minecraft.class_3730;
import net.minecraft.class_4048;
import net.minecraft.class_4050;
import net.minecraft.class_4538;
import net.minecraft.class_5132;
import net.minecraft.class_5134;
import net.minecraft.class_5425;
import net.minecraft.class_5766;
import net.minecraft.class_7;
import net.minecraft.entity.*;
import net.minecraft.entity.ai.goal.*;
import net.minecraft.world.*;
import org.jetbrains.annotations.Nullable;

import java.util.Optional;
import java.util.UUID;

public class DuckEntity extends class_1429 implements DuckLike {
    private static final class_2940<Optional<UUID>> FOLLOWING = class_2945.method_12791(DuckEntity.class, class_2943.field_13313);
    private static final class_1856 BREEDING_INGREDIENT = class_1856.method_8091(class_1802.field_8317, class_1802.field_46250, class_1802.field_46249, class_1802.field_8309, class_1802.field_42711, class_1802.field_43195);
    public float flapProgress;
    public float maxWingDeviation;
    public float prevMaxWingDeviation;
    public float prevFlapProgress;
    public float flapSpeed = 1f;
    @Nullable private class_1309 following;
    @Nullable private class_1309 follower;

    public DuckEntity(class_1299<? extends DuckEntity> entityType, class_1937 world) {
        super(entityType, world);
        method_5941(class_7.field_18, 0f);
        method_5941(class_7.field_4, 0f);
    }

    protected void method_5959() {
        field_6201.method_6277(0, new class_1347(this));
        field_6201.method_6277(1, new class_1374(this, 1.2d));
        field_6201.method_6277(2, new class_1341(this, 1d));
        field_6201.method_6277(3, new class_1391(this, 1d, BREEDING_INGREDIENT, false));
        field_6201.method_6277(4, new DuckCaravanGoal(this, 5, .85d));
        field_6201.method_6277(5, new WanderAroundFarInWaterGoal(this, .75d, .01f));
        field_6201.method_6277(6, new class_1361(this, class_1657.class, 5f));
        field_6201.method_6277(7, new class_1376(this));
    }

    public static class_5132.class_5133 createDuckAttributes() {
        return class_1308.method_26828().method_26868(class_5134.field_23716, 4d).method_26868(class_5134.field_23719, .25d);
    }

    @Override
    protected class_1408 method_5965(class_1937 world) {
        return new class_5766(this, world);
    }

    @Override
    public boolean method_5979(class_1936 world, class_3730 spawnReason) {
        if (world.method_22351(method_24515()) || world.method_22351(method_24515().method_10074())) {
            class_2338.class_2339 mutable = method_24515().method_25503();
            for (int y = method_31478(), depth = 0; y > world.method_31607(); --y) {
                mutable.method_33098(y);
                if (world.method_22351(mutable))
                    ++depth;
                else return true;

                if (depth > 4)
                    return false;
            }
        }
        return super.method_5979(world, spawnReason);
    }

    @Nullable
    @Override
    public class_1296 method_5613(class_3218 world, class_1296 entity) {
        DuckEntity child = FloraAndFaunaEntities.DUCK.method_5883(world);
        if (child != null) {
            child.follow(this);
        }
        return child;
    }

    @Override
    protected void method_5693() {
        super.method_5693();
        field_6011.method_12784(FOLLOWING, Optional.empty());
    }

    @Override
    public void method_5652(class_2487 nbt) {
        super.method_5652(nbt);
        if (gbw$getFollowing() != null)
            nbt.method_25927("Following", gbw$getFollowing().method_5667());
    }

    @Override
    public void method_5749(class_2487 nbt) {
        super.method_5749(nbt);
        if (nbt.method_10545("Following")) {
            UUID uuid = nbt.method_25926("Following");
            if (!method_37908().field_9236 && ((class_3218) method_37908()).method_14190(uuid) instanceof class_1308 mob) {
                follow(mob);
            }
        }
    }

    protected float method_18394(class_4050 pose, class_4048 dimensions) {
        return dimensions.field_18068;
    }

    @Override
    public float method_6144(class_2338 pos, class_4538 world) {
        class_2680 down = world.method_8320(pos.method_10074());
        if (down.method_27852(class_2246.field_10219) || world.method_22351(pos)) {
            return 10f;
        }
        return world.method_42309(pos);
    }

    public void method_6007() {
        super.method_6007();
        prevFlapProgress = flapProgress;
        prevMaxWingDeviation = maxWingDeviation;
        maxWingDeviation += (method_24828() ? -1f : 4f) * .3f;
        maxWingDeviation = class_3532.method_15363(maxWingDeviation, 0f, 1f);
        if (!method_24828() && flapSpeed < 1f) {
            flapSpeed = 1f;
        }

        flapSpeed *= .9f;
        class_243 vec3d = method_18798();
        if (!method_24828() && vec3d.field_1351 < 0d) {
            method_18799(vec3d.method_18805(1d, .75d, 1d));
        }

        flapProgress += flapSpeed * 2f;
    }

    public void method_6091(class_243 movementInput) {
        if (method_5787() && method_5799()) {
            method_5724(method_6029(), movementInput);
            method_5784(class_1313.field_6308, method_18798());
            class_243 velocity = method_18798();
            if (field_5976) {
                method_18799(new class_243(velocity.field_1352, .30000001192092896d, velocity.field_1350).method_18805(method_6120(), .800000011920929d, method_6120()));
            } else
                method_18799(velocity.method_1021(.5d));
        } else super.method_6091(movementInput);
    }

    protected boolean method_5776() {
        return field_28627 > 1f;
    }

    protected class_3414 method_5994() {
        return FloraAndFaunaSoundEvents.ENTITY_DUCK_QUACK;
    }

    protected class_3414 method_6011(class_1282 source) {
        return class_3417.field_14601;
    }

    protected class_3414 method_6002() {
        return class_3417.field_15140;
    }

    protected void method_5712(class_2338 pos, class_2680 state) {
        method_5783(class_3417.field_14685, .15f, 1f);
    }

    @Override
    public void method_5966() {
        if (field_5974.method_43048(4) == 0)
            super.method_5966();
    }

    @Override
    public boolean method_6481(class_1799 stack) {
        return BREEDING_INGREDIENT.method_8093(stack);
    }

    @Override
    public void gbw$setFollowing(@Nullable class_1309 living) {
        following = living;
        field_6011.method_12778(FOLLOWING, living == null ? Optional.empty() : Optional.of(living.method_5667()));
    }

    @Override
    public void gbw$setFollower(@Nullable class_1309 living) {
        if (living instanceof DuckLike duckLike) {
            duckLike.gbw$setFollowing(this);
            follower = living;
        }
    }

    @Override
    @Nullable
    public class_1309 gbw$getFollowing() {
        return following;
    }

    @Override
    @Nullable
    public class_1309 gbw$getFollower() {
        return follower;
    }

    @Override
    protected void method_5619() {
        if (gbw$getFollowing() != null) {
            stopFollowing();
        }
        super.method_5619();
    }

    public double method_29241() {
        return method_6109() ? .4d : .65d;
    }

    @Override
    public class_1315 method_5943(class_5425 world, class_1266 difficulty, class_3730 spawnReason, @Nullable class_1315 entityData, @Nullable class_2487 entityNbt) {
        if (entityData == null) {
            entityData = new DuckData();
        }
        DuckData duckData = (DuckData) entityData;
        if (++duckData.spawnCount > 1) {
            method_5614(-24000);
            class_1309 currentDuck = duckData.parent;
            int length = 0;
            while (currentDuck instanceof DuckLike duckLike && duckLike.hasFollower() && length <= 4) {
                class_1309 nextDuck = duckLike.gbw$getFollower();
                if (nextDuck instanceof DuckLike duckLike1 && duckLike1.hasFollower()) {
                    currentDuck = nextDuck;
                    ++length;
                } else {
                    if (nextDuck instanceof DuckLike duckLike1) {
                        if ((!duckLike1.isFollowing() && !nextDuck.method_6109()) || (nextDuck.method_6109() && !duckLike1.hasFollower())) {
                            follow(nextDuck);
                            continue;
                        }
                    }
                    break;
                }
            }
        } else
            duckData.parent = this;
        return duckData;
    }

    public static class DuckData implements class_1315 {
        private DuckEntity parent;
        private int spawnCount;
    }
}
