package dev.creoii.greatbigworld.floraandfauna.entity;

import net.minecraft.class_1309;
import org.jetbrains.annotations.Nullable;

public interface DuckLike {
    @Nullable
    class_1309 gbw$getFollowing();

    @Nullable
    class_1309 gbw$getFollower();

    void gbw$setFollowing(class_1309 duckLike);

    void gbw$setFollower(class_1309 duckLike);

    default boolean hasFollower() {
        return gbw$getFollower() != null;
    }

    default boolean isFollowing() {
        return gbw$getFollowing() != null;
    }

    default void stopFollowing() {
        if (gbw$getFollowing() instanceof DuckLike duckLike) {
            duckLike.gbw$setFollower(null);
        }
        gbw$setFollowing(null);
    }

    default void follow(class_1309 living) {
        gbw$setFollowing(living);
        if (gbw$getFollowing() instanceof DuckLike duckLike)
            duckLike.gbw$setFollower(null);
    }
}
