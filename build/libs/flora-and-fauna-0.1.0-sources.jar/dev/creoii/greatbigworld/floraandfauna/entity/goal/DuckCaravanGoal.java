package dev.creoii.greatbigworld.floraandfauna.entity.goal;

import dev.creoii.greatbigworld.floraandfauna.entity.DuckEntity;
import dev.creoii.greatbigworld.floraandfauna.entity.DuckLike;
import dev.creoii.greatbigworld.floraandfauna.registry.FloraAndFaunaCriteria;
import java.util.EnumSet;
import java.util.List;
import net.minecraft.class_1297;
import net.minecraft.class_1308;
import net.minecraft.class_1309;
import net.minecraft.class_1352;
import net.minecraft.class_1428;
import net.minecraft.class_243;
import net.minecraft.class_3218;
import net.minecraft.class_3222;

public class DuckCaravanGoal extends class_1352 {
    public final class_1308 duck;
    private final int maxCaravanLength;
    private final double speed;
    private int counter;

    public DuckCaravanGoal(class_1308 duck, int maxCaravanLength, double speed) {
        this.duck = duck;
        this.maxCaravanLength = maxCaravanLength;
        this.speed = speed;
        method_6265(EnumSet.of(class_1352.class_4134.field_18405));
    }

    @Override
    public boolean method_6264() {
        if (duck instanceof DuckLike duckLike) {
            if (duckLike.isFollowing() || !duck.method_6109()) {
                return false;
            }
            List<class_1297> followTargets = duck.method_37908().method_8333(duck, duck.method_5829().method_1009(9d, 3d, 9d), entity -> {
                return entity instanceof DuckLike duckLike1 && !duckLike1.hasFollower();
            });
            class_1309 living = null;
            for (class_1297 entity : followTargets) {
                if (entity instanceof DuckLike duckLike2) {
                    living = (class_1309) entity;
                    if ((!duckLike2.isFollowing() && !living.method_6109()) || (living.method_6109() && !duckLike2.hasFollower())) {
                        break;
                    }
                }
            }
            if (living == null)
                return false;
            duckLike.follow(living);
            if (!living.method_6109() && duck.method_37908() instanceof class_3218 serverWorld && living instanceof class_1428 && duck instanceof DuckEntity) {
                class_3222 serverPlayer = (class_3222) serverWorld.method_18460(duck, 16d);
                if (serverPlayer != null) {
                    FloraAndFaunaCriteria.DUCK_FOLLOW_CHICKEN.method_22510(serverPlayer, conditions -> true);
                }
            }
            return true;
        }
        return false;
    }

    @Override
    public boolean method_6266() {
        if (duck instanceof DuckLike duckLike && duckLike.isFollowing() && duckLike.gbw$getFollowing() != null && duckLike.gbw$getFollowing().method_5805()) {
            double d = duck.method_5858(duckLike.gbw$getFollowing());
            if (d > 676d) {
                if (speed <= 3d) {
                    counter = method_38848(40);
                    return true;
                }
                if (counter == 0) {
                    return false;
                }
            }
            if (counter > 0) {
                --counter;
            }
            return true;
        }
        return false;
    }

    @Override
    public void method_6270() {
        if (duck instanceof DuckLike duckLike)
            duckLike.stopFollowing();
    }

    @Override
    public void method_6268() {
        if (duck instanceof DuckLike duckLike) {
            if (!duckLike.isFollowing()) {
                return;
            }
            class_1309 living = duckLike.gbw$getFollowing();
            double d = duck.method_5739(living);
            class_243 vec3d = new class_243(living.method_23317() - duck.method_23317(), living.method_23318() - duck.method_23318(), living.method_23321() - duck.method_23321()).method_1029().method_1021(Math.max(d - .2d, 0d));
            duck.method_5942().method_6337(duck.method_23317() + vec3d.field_1352, duck.method_23318() + vec3d.field_1351, duck.method_23321() + vec3d.field_1350, speed);
        }
    }
}
