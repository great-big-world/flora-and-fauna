package dev.creoii.greatbigworld.floraandfauna.entity.goal;

import dev.creoii.greatbigworld.floraandfauna.util.FuzzyTargetingHelper;
import net.minecraft.class_1314;
import net.minecraft.class_1379;
import net.minecraft.class_243;
import org.jetbrains.annotations.Nullable;

public class WanderAroundFarInWaterGoal extends class_1379 {
    protected final float probability;

    public WanderAroundFarInWaterGoal(class_1314 mob, double speed, float probability) {
        super(mob, speed);
        this.probability = probability;
    }

    @Nullable
    protected class_243 method_6302() {
        if (field_6566.method_5816()) {
            class_243 vec3d = FuzzyTargetingHelper.findIgnoreWater(field_6566, 15, 7);
            return vec3d == null ? super.method_6302() : vec3d;
        }
        return field_6566.method_6051().method_43057() >= probability ? FuzzyTargetingHelper.findIgnoreWater(field_6566, 10, 7) : super.method_6302();
    }
}
