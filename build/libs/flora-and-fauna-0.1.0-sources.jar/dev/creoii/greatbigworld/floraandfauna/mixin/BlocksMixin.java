package dev.creoii.greatbigworld.floraandfauna.mixin;

import net.minecraft.class_2246;
import net.minecraft.class_4970;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArg;

@Mixin(class_2246.class)
public class BlocksMixin {
    @ModifyArg(method = "<clinit>", at = @At(value = "INVOKE", target = "Lnet/minecraft/block/ShortPlantBlock;<init>(Lnet/minecraft/block/AbstractBlock$Settings;)V"))
    private static class_4970.class_2251 gbw$modifyShortPlantSettings(class_4970.class_2251 settings) {
        return settings.method_9624();
    }

    @ModifyArg(method = "<clinit>", at = @At(value = "INVOKE", target = "Lnet/minecraft/block/SeagrassBlock;<init>(Lnet/minecraft/block/AbstractBlock$Settings;)V"))
    private static class_4970.class_2251 gbw$modifySeagrassSettings(class_4970.class_2251 settings) {
        return settings.method_9624();
    }

    @ModifyArg(method = "<clinit>", at = @At(value = "INVOKE", target = "Lnet/minecraft/block/TallSeagrassBlock;<init>(Lnet/minecraft/block/AbstractBlock$Settings;)V"))
    private static class_4970.class_2251 gbw$modifyTallSeagrassSettings(class_4970.class_2251 settings) {
        return settings.method_9624();
    }

    @ModifyArg(method = "<clinit>", at = @At(value = "INVOKE", target = "Lnet/minecraft/block/FlowerBlock;<init>(Lnet/minecraft/entity/effect/StatusEffect;ILnet/minecraft/block/AbstractBlock$Settings;)V"))
    private static class_4970.class_2251 gbw$modifyFlowerSettings(class_4970.class_2251 settings) {
        return settings.method_9624();
    }

    @ModifyArg(method = "<clinit>", at = @At(value = "INVOKE", target = "Lnet/minecraft/block/WitherRoseBlock;<init>(Lnet/minecraft/entity/effect/StatusEffect;ILnet/minecraft/block/AbstractBlock$Settings;)V"))
    private static class_4970.class_2251 gbw$modifyWitherRoseSettings(class_4970.class_2251 settings) {
        return settings.method_9624();
    }

    @ModifyArg(method = "<clinit>", at = @At(value = "INVOKE", target = "Lnet/minecraft/block/TallFlowerBlock;<init>(Lnet/minecraft/block/AbstractBlock$Settings;)V"))
    private static class_4970.class_2251 gbw$modifyTallFlowerSettings(class_4970.class_2251 settings) {
        return settings.method_9624();
    }

    @ModifyArg(method = "<clinit>", at = @At(value = "INVOKE", target = "Lnet/minecraft/block/TallPlantBlock;<init>(Lnet/minecraft/block/AbstractBlock$Settings;)V"))
    private static class_4970.class_2251 gbw$modifyTallPlantSettings(class_4970.class_2251 settings) {
        return settings.method_9624();
    }

    @ModifyArg(method = "<clinit>", at = @At(value = "INVOKE", target = "Lnet/minecraft/block/SmallDripleafBlock;<init>(Lnet/minecraft/block/AbstractBlock$Settings;)V"))
    private static class_4970.class_2251 gbw$modifySmallDripleafSettings(class_4970.class_2251 settings) {
        return settings.method_9624();
    }

    @ModifyArg(method = "<clinit>", at = @At(value = "INVOKE", target = "Lnet/minecraft/block/MushroomPlantBlock;<init>(Lnet/minecraft/registry/RegistryKey;Lnet/minecraft/block/AbstractBlock$Settings;)V"))
    private static class_4970.class_2251 gbw$modifyMushroomPlantSettings(class_4970.class_2251 settings) {
        return settings.method_9624();
    }
}
