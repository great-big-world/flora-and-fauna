package dev.creoii.greatbigworld.floraandfauna.mixin.block;

import dev.creoii.greatbigworld.floraandfauna.season.Season;
import dev.creoii.greatbigworld.floraandfauna.season.SeasonManager;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.List;
import net.minecraft.class_1297;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_4482;

@Mixin(class_4482.class)
public class BeehiveBlockEntityMixin {
    @Inject(method = "releaseBee", at = @At("HEAD"), cancellable = true)
    private static void gbw$dontReleaseBeeDuringWinter(class_1937 world, class_2338 pos, class_2680 state, class_4482.class_4483 bee, @Nullable List<class_1297> entities, class_4482.class_4484 beeState, @Nullable class_2338 flowerPos, CallbackInfoReturnable<Boolean> cir) {
        if (!world.field_9236) {
            if (SeasonManager.getInstance(((class_3218) world).method_8503()).getCurrentSeason() == Season.WINTER && beeState != class_4482.class_4484.field_21052)
                cir.setReturnValue(false);
        }
    }
}
