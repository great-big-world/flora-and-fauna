package dev.creoii.greatbigworld.floraandfauna.mixin.block;

import dev.creoii.greatbigworld.floraandfauna.client.FloraAndFaunaClient;
import dev.creoii.greatbigworld.floraandfauna.season.Season;
import dev.creoii.greatbigworld.floraandfauna.util.FloraAndFaunaTags;
import dev.creoii.greatbigworld.floraandfauna.util.SnowyHelper;
import net.minecraft.block.*;
import net.minecraft.class_10;
import net.minecraft.class_1750;
import net.minecraft.class_1802;
import net.minecraft.class_1922;
import net.minecraft.class_1944;
import net.minecraft.class_1959;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2256;
import net.minecraft.class_2261;
import net.minecraft.class_2338;
import net.minecraft.class_2420;
import net.minecraft.class_2488;
import net.minecraft.class_259;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2758;
import net.minecraft.class_2975;
import net.minecraft.class_3218;
import net.minecraft.class_3726;
import net.minecraft.class_5321;
import net.minecraft.class_5819;
import net.minecraft.class_6880;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_2420.class)
public abstract class MushroomPlantBlockMixin extends class_2261 implements class_2256 {
    @Unique
    private static final class_2758 MUSHROOMS = class_2758.method_11867("mushrooms", 1, 4);
    @Unique
    private static final class_265 LARGE_SHAPE = class_2248.method_9541(3.5d, 0d, 3.5d, 12.5d, 10d, 12.5d);

    protected MushroomPlantBlockMixin(class_2251 settings) {
        super(settings);
    }

    @Inject(method = "<init>", at = @At("TAIL"))
    private void gbw$setSnowyDefaultState(class_5321<class_2975<?, ?>> featureKey, class_2251 settings, CallbackInfo ci) {
        method_9590(method_9595().method_11664().method_11657(MUSHROOMS, 1).method_11657(SnowyHelper.SNOW_LAYERS, 0));
    }

    @Inject(method = "getOutlineShape", at = @At("RETURN"), cancellable = true)
    private void gbw$mergeSnowShape(class_2680 state, class_1922 world, class_2338 pos, class_3726 context, CallbackInfoReturnable<class_265> cir) {
        class_265 snowShape = class_259.method_1073();
        if (SnowyHelper.isSnowy(state)) {
            snowShape = SnowyHelper.getSnowShape(state);
        }
        cir.setReturnValue(class_259.method_1084(state.method_11654(MUSHROOMS) > 2 ? LARGE_SHAPE : cir.getReturnValue(), snowShape));
    }

    public boolean method_9516(class_2680 state, class_1922 world, class_2338 pos, class_10 type) {
        if (type == class_10.field_50)
            return state.method_11654(SnowyHelper.SNOW_LAYERS) < 5;
        return false;
    }

    @Override
    public boolean method_9542(class_2680 state) {
        return SnowyHelper.isSnowy(state);
    }

    @SuppressWarnings("deprecation")
    public void method_9514(class_2680 state, class_3218 world, class_2338 pos, class_5819 random) {
        class_6880<class_1959> biomeEntry = world.method_23753(pos);
        if (world.method_8314(class_1944.field_9282, pos) > 11 || (FloraAndFaunaClient.getCurrentSeason() != Season.WINTER && !biomeEntry.method_40220(FloraAndFaunaTags.NOT_AFFECTED_BY_WINTER) && biomeEntry.comp_349().method_39927(pos))) {
            if (state.method_11654(SnowyHelper.SNOW_LAYERS) > 0)
                method_9497(class_2246.field_10477.method_9564().method_11657(class_2488.field_11518, state.method_11654(SnowyHelper.SNOW_LAYERS)), world, pos);
            world.method_8501(pos, state.method_11657(SnowyHelper.SNOW_LAYERS, 0));
        }
    }

    @SuppressWarnings("deprecation")
    public class_265 method_9549(class_2680 state, class_1922 world, class_2338 pos, class_3726 context) {
        if (SnowyHelper.isSnowy(state)) {
            return SnowyHelper.LAYERS_TO_SHAPE[state.method_11654(SnowyHelper.SNOW_LAYERS) - 1];
        }
        return class_259.method_1073();
    }

    @SuppressWarnings("deprecation")
    public class_265 method_25959(class_2680 state, class_1922 world, class_2338 pos) {
        if (SnowyHelper.isSnowy(state)) {
            return SnowyHelper.getSnowShape(state);
        }
        return class_259.method_1073();
    }

    @SuppressWarnings("deprecation")
    public class_265 method_26159(class_2680 state, class_1922 world, class_2338 pos, class_3726 context) {
        if (SnowyHelper.isSnowy(state)) {
            return SnowyHelper.getSnowShape(state);
        }
        return class_259.method_1073();
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(MUSHROOMS, SnowyHelper.SNOW_LAYERS);
    }

    @Nullable
    @Override
    public class_2680 method_9605(class_1750 ctx) {
        class_2680 state = ctx.method_8045().method_8320(ctx.method_8037());
        if (state.method_27852(class_2246.field_10477)) {
            return method_9564().method_11657(SnowyHelper.SNOW_LAYERS, state.method_11654(class_2488.field_11518));
        } else if (state.method_27852(this)) {
            return state.method_11657(MUSHROOMS, Math.min(4, state.method_11654(MUSHROOMS) + 1));
        }
        return super.method_9605(ctx);
    }

    @SuppressWarnings("deprecation")
    public boolean method_9616(class_2680 state, class_1750 context) {
        return !context.method_8046() && ((context.method_8041().method_31574(method_8389()) && state.method_11654(MUSHROOMS) < 4) || (context.method_8041().method_31574(class_1802.field_8749) && state.method_11654(SnowyHelper.SNOW_LAYERS) < 8)) || super.method_9616(state, context);
    }
}
