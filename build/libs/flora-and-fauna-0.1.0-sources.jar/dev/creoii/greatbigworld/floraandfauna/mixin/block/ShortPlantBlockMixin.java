package dev.creoii.greatbigworld.floraandfauna.mixin.block;

import dev.creoii.greatbigworld.floraandfauna.client.FloraAndFaunaClient;
import dev.creoii.greatbigworld.floraandfauna.season.Season;
import dev.creoii.greatbigworld.floraandfauna.util.FloraAndFaunaTags;
import dev.creoii.greatbigworld.floraandfauna.util.SnowyHelper;
import net.minecraft.block.*;
import net.minecraft.class_10;
import net.minecraft.class_1750;
import net.minecraft.class_1802;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_1944;
import net.minecraft.class_1959;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2256;
import net.minecraft.class_2261;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2488;
import net.minecraft.class_2526;
import net.minecraft.class_259;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_3218;
import net.minecraft.class_3726;
import net.minecraft.class_5819;
import net.minecraft.class_6880;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_2526.class)
public abstract class ShortPlantBlockMixin extends class_2261 implements class_2256 {
    protected ShortPlantBlockMixin(class_2251 settings) {
        super(settings);
    }

    @Inject(method = "<init>", at = @At("TAIL"))
    private void gbw$setSnowyDefaultState(class_2251 settings, CallbackInfo ci) {
        method_9590(method_9595().method_11664().method_11657(SnowyHelper.SNOW_LAYERS, 0));
    }

    @Inject(method = "getOutlineShape", at = @At("RETURN"), cancellable = true)
    private void gbw$mergeSnowShape(class_2680 state, class_1922 world, class_2338 pos, class_3726 context, CallbackInfoReturnable<class_265> cir) {
        if (SnowyHelper.isSnowy(state)) {
            cir.setReturnValue(class_259.method_1084(cir.getReturnValue(), SnowyHelper.getSnowShape(state)));
        }
    }

    @Override
    public boolean method_9542(class_2680 state) {
        return SnowyHelper.isSnowy(state);
    }

    @SuppressWarnings("deprecation")
    public void method_9514(class_2680 state, class_3218 world, class_2338 pos, class_5819 random) {
        class_6880<class_1959> biomeEntry = world.method_23753(pos);
        if (world.method_8314(class_1944.field_9282, pos) > 11 || (FloraAndFaunaClient.getCurrentSeason() != Season.WINTER && !biomeEntry.method_40220(FloraAndFaunaTags.NOT_AFFECTED_BY_WINTER) && biomeEntry.comp_349().method_39927(pos))) {
            method_9497(state, world, pos);
            world.method_8501(pos, state.method_11657(SnowyHelper.SNOW_LAYERS, 0));
        }
    }

    @Override
    @SuppressWarnings("deprecation")
    public boolean method_9616(class_2680 state, class_1750 context) {
        if (super.method_9616(state, context))
            return true;
        int i = state.method_11654(SnowyHelper.SNOW_LAYERS);
        if (context.method_8041().method_31574(class_1802.field_8749) && i < 8) {
            if (context.method_7717()) {
                return context.method_8038() == class_2350.field_11036;
            } else {
                return true;
            }
        } else {
            return i == 1;
        }
    }

    public boolean method_9516(class_2680 state, class_1922 world, class_2338 pos, class_10 type) {
        if (type == class_10.field_50)
            return state.method_11654(SnowyHelper.SNOW_LAYERS) < 5;
        return false;
    }

    @SuppressWarnings("deprecation")
    public class_265 method_9549(class_2680 state, class_1922 world, class_2338 pos, class_3726 context) {
        if (SnowyHelper.isSnowy(state)) {
            return SnowyHelper.LAYERS_TO_SHAPE[state.method_11654(SnowyHelper.SNOW_LAYERS) - 1];
        }
        return class_259.method_1073();
    }

    @SuppressWarnings("deprecation")
    public class_265 method_25959(class_2680 state, class_1922 world, class_2338 pos) {
        if (SnowyHelper.isSnowy(state)) {
            return SnowyHelper.getSnowShape(state);
        }
        return class_259.method_1073();
    }

    @SuppressWarnings("deprecation")
    public class_265 method_26159(class_2680 state, class_1922 world, class_2338 pos, class_3726 context) {
        if (SnowyHelper.isSnowy(state)) {
            return SnowyHelper.getSnowShape(state);
        }
        return class_259.method_1073();
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(SnowyHelper.SNOW_LAYERS);
    }

    @Nullable
    @Override
    public class_2680 method_9605(class_1750 ctx) {
        class_1937 world = ctx.method_8045();
        class_2338 pos = ctx.method_8037();

        class_2680 state = world.method_8320(pos);
        if (state.method_27852(class_2246.field_10477)) {
            return method_9564().method_11657(SnowyHelper.SNOW_LAYERS, state.method_11654(class_2488.field_11518));
        }

        return super.method_9605(ctx);
    }
}
