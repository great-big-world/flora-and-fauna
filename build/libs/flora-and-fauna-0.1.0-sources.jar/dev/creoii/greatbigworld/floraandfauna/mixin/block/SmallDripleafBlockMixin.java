package dev.creoii.greatbigworld.floraandfauna.mixin.block;

import dev.creoii.greatbigworld.floraandfauna.util.SnowyHelper;
import net.minecraft.block.*;
import net.minecraft.class_2248;
import net.minecraft.class_2256;
import net.minecraft.class_2320;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2746;
import net.minecraft.class_2753;
import net.minecraft.class_2756;
import net.minecraft.class_3737;
import net.minecraft.class_4970;
import net.minecraft.class_5808;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_5808.class)
public abstract class SmallDripleafBlockMixin extends class_2320 implements class_2256, class_3737 {
    @Shadow @Final private static class_2746 WATERLOGGED;
    @Shadow @Final public static class_2753 FACING;

    public SmallDripleafBlockMixin(class_2251 settings) {
        super(settings);
    }

    @Inject(method = "<init>", at = @At("TAIL"))
    private void gbw$setSnowyDefaultState(class_4970.class_2251 settings, CallbackInfo ci) {
        method_9590(field_10647.method_11664().method_11657(field_10929, class_2756.field_12607).method_11657(WATERLOGGED, false).method_11657(FACING, class_2350.field_11043).method_11657(SnowyHelper.SNOW_LAYERS, 0));
    }

    @Inject(method = "appendProperties", at = @At("TAIL"))
    private void gbw$addSnowyProperty(class_2689.class_2690<class_2248, class_2680> builder, CallbackInfo ci) {
        builder.method_11667(SnowyHelper.SNOW_LAYERS);
    }
}
