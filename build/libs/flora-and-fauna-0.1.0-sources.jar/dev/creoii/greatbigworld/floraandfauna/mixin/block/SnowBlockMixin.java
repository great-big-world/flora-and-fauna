package dev.creoii.greatbigworld.floraandfauna.mixin.block;

import com.llamalad7.mixinextras.sugar.Local;
import dev.creoii.greatbigworld.floraandfauna.client.FloraAndFaunaClient;
import dev.creoii.greatbigworld.floraandfauna.season.Season;
import dev.creoii.greatbigworld.floraandfauna.season.SeasonManager;
import dev.creoii.greatbigworld.floraandfauna.util.FloraAndFaunaTags;
import dev.creoii.greatbigworld.floraandfauna.util.SnowyHelper;
import net.minecraft.class_1750;
import net.minecraft.class_1944;
import net.minecraft.class_1959;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2488;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_4538;
import net.minecraft.class_5819;
import net.minecraft.class_6880;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_2488.class)
public abstract class SnowBlockMixin extends class_2248 {
    public SnowBlockMixin(class_2251 settings) {
        super(settings);
    }

    @Inject(method = "getPlacementState", at = @At(value = "RETURN", ordinal = 1), cancellable = true)
    private void gbw$layerSnow(class_1750 ctx, CallbackInfoReturnable<class_2680> cir, @Local class_2680 blockState) {
        if (blockState.method_28498(SnowyHelper.SNOW_LAYERS)) {
            int i = blockState.method_11654(SnowyHelper.SNOW_LAYERS);
            cir.setReturnValue(blockState.method_11657(SnowyHelper.SNOW_LAYERS, Math.min(8, i + 1)));
        }
    }

    @Inject(method = "canPlaceAt", at = @At(value = "INVOKE", target = "Lnet/minecraft/block/BlockState;isIn(Lnet/minecraft/registry/tag/TagKey;)Z", ordinal = 0), cancellable = true)
    private void gbw$canPlaceOnSnowyPlants(class_2680 state, class_4538 world, class_2338 pos, CallbackInfoReturnable<Boolean> cir, @Local(ordinal = 1) class_2680 blockState) {
        if (blockState.method_28498(SnowyHelper.SNOW_LAYERS) && blockState.method_11654(SnowyHelper.SNOW_LAYERS) == 8) {
            cir.setReturnValue(true);
        }
    }

    @Inject(method = "randomTick", at = @At("HEAD"), cancellable = true)
    private void gbw$meltInNonWinterSeason(class_2680 state, class_3218 world, class_2338 pos, class_5819 random, CallbackInfo ci) {
        class_6880<class_1959> biomeEntry = world.method_23753(pos);
        if (world.method_8314(class_1944.field_9282, pos) > 11 || (FloraAndFaunaClient.getCurrentSeason() != Season.WINTER && !biomeEntry.method_40220(FloraAndFaunaTags.NOT_AFFECTED_BY_WINTER) && biomeEntry.comp_349().method_39927(pos))) {
            method_9497(state, world, pos);
            world.method_8650(pos, false);
            ci.cancel();
        }
    }
}
