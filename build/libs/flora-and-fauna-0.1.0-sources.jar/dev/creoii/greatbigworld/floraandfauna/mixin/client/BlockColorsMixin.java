package dev.creoii.greatbigworld.floraandfauna.mixin.client;

import dev.creoii.greatbigworld.floraandfauna.client.FloraAndFaunaClient;
import dev.creoii.greatbigworld.floraandfauna.season.Season;
import dev.creoii.greatbigworld.floraandfauna.season.SeasonManager;
import dev.creoii.greatbigworld.floraandfauna.util.FloraAndFaunaTags;
import net.minecraft.class_1920;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_324;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_324.class)
public class BlockColorsMixin {
    @Inject(method = "getColor", at = @At("RETURN"), cancellable = true)
    private void gbw$modifyBlockColor(class_2680 state, class_1920 world, class_2338 pos, int tintIndex, CallbackInfoReturnable<Integer> cir) {
        if (!state.method_26164(FloraAndFaunaTags.IGNORE_SEASON_COLOR)) {
            Season season = FloraAndFaunaClient.getCurrentSeason();
            if (season != null) {
                cir.setReturnValue(SeasonManager.getColor(world, pos, cir.getReturnValue()));
            }
        }
    }

    @Inject(method = "getColor", at = @At(value = "RETURN", ordinal = 0), cancellable = true)
    private void gbw$modifyParticleColor(class_2680 state, class_1920 world, class_2338 pos, int tintIndex, CallbackInfoReturnable<Integer> cir) {
        if (!state.method_26164(FloraAndFaunaTags.IGNORE_SEASON_COLOR)) {
            Season season = FloraAndFaunaClient.getCurrentSeason();
            if (season != null) {
                cir.setReturnValue(SeasonManager.getColor(world, pos, cir.getReturnValue()));
            }
        }
    }
}
