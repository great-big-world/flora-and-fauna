package dev.creoii.greatbigworld.floraandfauna.mixin.client;

import dev.creoii.greatbigworld.floraandfauna.client.FloraAndFaunaClient;
import dev.creoii.greatbigworld.floraandfauna.season.SeasonManager;
import dev.creoii.greatbigworld.floraandfauna.util.FloraAndFaunaTags;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.function.Supplier;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2874;
import net.minecraft.class_3695;
import net.minecraft.class_5269;
import net.minecraft.class_5321;
import net.minecraft.class_5455;
import net.minecraft.class_638;
import net.minecraft.class_6539;
import net.minecraft.class_6880;

@Mixin(class_638.class)
public abstract class ClientWorldMixin extends class_1937 {
    protected ClientWorldMixin(class_5269 properties, class_5321<class_1937> registryRef, class_5455 registryManager, class_6880<class_2874> dimensionEntry, Supplier<class_3695> profiler, boolean isClient, boolean debugWorld, long biomeAccess, int maxChainedNeighborUpdates) {
        super(properties, registryRef, registryManager, dimensionEntry, profiler, isClient, debugWorld, biomeAccess, maxChainedNeighborUpdates);
    }

    @Inject(method = "calculateColor", at = @At("RETURN"), cancellable = true)
    private void gbw$modifyBlockColor(class_2338 pos, class_6539 colorResolver, CallbackInfoReturnable<Integer> cir) {
        if (!method_8320(pos).method_26164(FloraAndFaunaTags.IGNORE_SEASON_COLOR)) {
            if (FloraAndFaunaClient.getCurrentSeason() != null) {
                cir.setReturnValue(SeasonManager.getColor(this, pos, cir.getReturnValue()));
            }
        }
    }
}
