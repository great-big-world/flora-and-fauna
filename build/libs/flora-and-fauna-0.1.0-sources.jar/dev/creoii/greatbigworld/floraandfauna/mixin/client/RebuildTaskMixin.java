package dev.creoii.greatbigworld.floraandfauna.mixin.client;

import com.llamalad7.mixinextras.sugar.Local;
import dev.creoii.greatbigworld.floraandfauna.util.SnowyHelper;
import net.minecraft.class_1921;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2488;
import net.minecraft.class_2680;
import net.minecraft.class_287;
import net.minecraft.class_4587;
import net.minecraft.class_5819;
import net.minecraft.class_750;
import net.minecraft.class_776;
import net.minecraft.class_846;
import net.minecraft.class_853;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_846.class_851.class_4578.class)
public class RebuildTaskMixin {
    @Inject(method = "render", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/render/block/BlockRenderManager;renderBlock(Lnet/minecraft/block/BlockState;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/world/BlockRenderView;Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumer;ZLnet/minecraft/util/math/random/Random;)V"))
    private void gbw$renderSnowOverlay(float cameraX, float cameraY, float cameraZ, class_750 storage, CallbackInfoReturnable<class_846.class_851.class_4578.class_7435> cir, @Local class_853 chunkRendererRegion, @Local class_4587 matrixStack, @Local class_5819 random, @Local class_776 blockRenderManager, @Local class_2680 blockState, @Local(ordinal = 2) class_2338 blockPos3) {
        if (blockState.method_28498(SnowyHelper.SNOW_LAYERS) && blockState.method_11654(SnowyHelper.SNOW_LAYERS) > 0) {
            class_287 bufferBuilder = storage.method_3154(class_1921.method_23577());
            if (bufferBuilder.method_22893()) {
                blockRenderManager.method_3355(class_2246.field_10477.method_9564().method_11657(class_2488.field_11518, blockState.method_11654(SnowyHelper.SNOW_LAYERS)), blockPos3, chunkRendererRegion, matrixStack, bufferBuilder, true, random);
            }
        }
    }
}
