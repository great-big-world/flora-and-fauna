package dev.creoii.greatbigworld.floraandfauna.mixin.client;

import dev.creoii.greatbigworld.floraandfauna.client.FloraAndFaunaClient;
import dev.creoii.greatbigworld.floraandfauna.season.Season;
import dev.creoii.greatbigworld.floraandfauna.util.FloraAndFaunaTags;
import net.minecraft.class_1959;
import net.minecraft.class_2338;
import net.minecraft.class_638;
import net.minecraft.class_761;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(class_761.class)
public class WorldRendererMixin {
    @Shadow private @Nullable class_638 world;

    @Redirect(method = "renderWeather", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/biome/Biome;getPrecipitation(Lnet/minecraft/util/math/BlockPos;)Lnet/minecraft/world/biome/Biome$Precipitation;"))
    private class_1959.class_1963 gbw$modifyPrecipitationForWinter(class_1959 instance, class_2338 pos) {
        return FloraAndFaunaClient.getCurrentSeason() == Season.WINTER && !world.method_23753(pos).method_40220(FloraAndFaunaTags.NOT_AFFECTED_BY_WINTER) ? class_1959.class_1963.field_9383 : instance.method_48162(pos);
    }

    @Redirect(method = "tickRainSplashing", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/biome/Biome;getPrecipitation(Lnet/minecraft/util/math/BlockPos;)Lnet/minecraft/world/biome/Biome$Precipitation;"))
    private class_1959.class_1963 gbw$modifyRainSplashingForWinter(class_1959 instance, class_2338 pos) {
        return FloraAndFaunaClient.getCurrentSeason() == Season.WINTER && !world.method_23753(pos).method_40220(FloraAndFaunaTags.NOT_AFFECTED_BY_WINTER) ? class_1959.class_1963.field_9383 : instance.method_48162(pos);
    }
}
