package dev.creoii.greatbigworld.floraandfauna.mixin.compat.visuality;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.llamalad7.mixinextras.sugar.Local;
import dev.creoii.greatbigworld.floraandfauna.client.FloraAndFaunaClient;
import dev.creoii.greatbigworld.floraandfauna.season.Season;
import dev.creoii.greatbigworld.floraandfauna.util.FloraAndFaunaTags;
import net.minecraft.class_1959;
import net.minecraft.class_2338;
import net.minecraft.class_638;
import net.minecraft.class_742;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import visuality.event.CirclesOnWaterEvent;

@Mixin(CirclesOnWaterEvent.class)
public class CirclesOnWaterEventMixin {
    @Shadow static class_742 player;

    @WrapOperation(method = "onTick", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/biome/Biome;doesNotSnow(Lnet/minecraft/util/math/BlockPos;)Z"))
    private static boolean gbw$noRainSplashDuringSnow(class_1959 instance, class_2338 pos, Operation<Boolean> original, @Local(argsOnly = true) class_638 var0) {
        return original.call(instance, pos) && (FloraAndFaunaClient.getCurrentSeason() != Season.WINTER || var0.method_23753(player.method_23312()).method_40220(FloraAndFaunaTags.NOT_AFFECTED_BY_WINTER));
    }
}
