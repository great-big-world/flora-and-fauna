package dev.creoii.greatbigworld.floraandfauna.mixin.entity;

import dev.creoii.greatbigworld.floraandfauna.util.FloraAndFaunaTags;
import net.minecraft.class_1282;
import net.minecraft.class_1296;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1429;
import net.minecraft.class_1937;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1429.class)
public abstract class AnimalEntityMixin extends class_1296 {
    protected AnimalEntityMixin(class_1299<? extends class_1296> entityType, class_1937 world) {
        super(entityType, world);
    }

    @Inject(method = "damage", at = @At(value = "RETURN", ordinal = 1))
    private void gbw$betterAnimalThreatResponse(class_1282 source, float amount, CallbackInfoReturnable<Boolean> cir) {
        if (source.method_48789(FloraAndFaunaTags.ALERTS_ANIMALS) && source.method_5529() instanceof class_1309 attacker) {
            method_37908().method_8333(null, method_5829().method_1014(12d), entity -> entity instanceof class_1429).forEach(entity -> {                                                   // enchantment for this value
                if (entity instanceof class_1309 living && (living.method_5858(attacker) < 16d || (attacker.method_5720().method_1029().method_1026(living.method_5720().method_1029()) < -.333334d && living.method_6057(attacker)))) {
                    living.method_6015(attacker);
                }
            });
        }
    }
}
