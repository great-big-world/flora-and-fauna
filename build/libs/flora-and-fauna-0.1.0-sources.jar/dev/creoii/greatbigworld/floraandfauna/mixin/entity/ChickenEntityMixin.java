package dev.creoii.greatbigworld.floraandfauna.mixin.entity;

import dev.creoii.greatbigworld.floraandfauna.entity.DuckLike;
import net.minecraft.class_1309;
import net.minecraft.class_1428;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;

@Mixin(class_1428.class)
public class ChickenEntityMixin implements DuckLike {
    @Unique
    @Nullable
    private class_1309 gbw$follower;

    @Override
    public class_1309 gbw$getFollowing() {
        return null;
    }

    @Override
    public class_1309 gbw$getFollower() {
        return gbw$follower;
    }

    @Override
    public void gbw$setFollowing(class_1309 duckLike) {}

    @Override
    public void gbw$setFollower(class_1309 duckLike) {
        gbw$follower = duckLike;
    }
}
