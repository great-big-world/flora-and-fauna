package dev.creoii.greatbigworld.floraandfauna.mixin.entity;

import dev.creoii.greatbigworld.floraandfauna.block.HollowLogBlock;
import dev.creoii.greatbigworld.floraandfauna.util.FloraAndFaunaTags;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.Optional;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1313;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2382;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_4050;

@Mixin(class_1297.class)
public abstract class EntityMixin {
    @Shadow public abstract class_1937 getWorld();
    @Shadow public abstract class_2338 getBlockPos();
    @Shadow public abstract float getWidth();
    @Shadow public abstract float getHeight();
    @Shadow public abstract boolean isSprinting();
    @Shadow public abstract boolean hasPassengers();
    @Shadow public abstract void setSwimming(boolean swimming);
    @Shadow public abstract void setPose(class_4050 pose);
    @Shadow public abstract class_1299<?> getType();
    @Shadow public abstract class_2350 getHorizontalFacing();
    @Shadow public abstract boolean isInPose(class_4050 pose);

    @Inject(method = "move", at = @At(value = "INVOKE", target = "Lnet/minecraft/util/profiler/Profiler;pop()V", ordinal = 2))
    private void gbw$crawlIntoHollowLogs(class_1313 movementType, class_243 movement, CallbackInfo ci) {
        if (isInPose(class_4050.field_18079) || !isSprinting() || hasPassengers())
            return;
        Optional<class_2338> optionalPos = class_2338.method_25997(getBlockPos(), (int) (getWidth() + .5f), (int) (getHeight() + .5f), pos -> {
            class_2338 difference = pos.method_10059(getBlockPos());
            if (difference.method_10264() > .5d || difference.method_10264() < -.5d || difference.equals(class_2338.field_10980))
                return false;
            class_2680 state = getWorld().method_8320(pos);
            if (state.method_26164(FloraAndFaunaTags.HOLLOW_LOGS)) {
                class_2382 facingVec = getHorizontalFacing().method_10163();
                return switch (state.method_11654(HollowLogBlock.field_11459)) {
                    case field_11048 -> difference.method_10263() != 0d && difference.method_10263() == facingVec.method_10263() && difference.method_10260() == 0d;
                    case field_11051 -> difference.method_10260() != 0d && difference.method_10260() == facingVec.method_10260() && difference.method_10263() == 0d;
                    case field_11052 -> false;
                };
            }
            return false;
        });

        if (optionalPos.isPresent()) {
            setSwimming(true);
            setPose(class_4050.field_18079);
        }
    }
}
