package dev.creoii.greatbigworld.floraandfauna.mixin.entity;

import net.minecraft.class_1314;
import net.minecraft.class_1374;
import net.minecraft.class_243;
import net.minecraft.class_5532;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(class_1374.class)
public class EscapeDangerGoalMixin {
    @Redirect(method = "findTarget", at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/ai/NoPenaltyTargeting;find(Lnet/minecraft/entity/mob/PathAwareEntity;II)Lnet/minecraft/util/math/Vec3d;"))
    private class_243 gbw$improveEscapeDangerPos(class_1314 entity, int horizontalRange, int verticalRange) {
        class_243 vec3d = class_5532.method_31510(entity, horizontalRange, verticalRange);
        if (vec3d != null && entity.method_6065() != null) {
            class_243 distance = entity.method_19538().method_1020(entity.method_6065().method_19538());
            class_243 direction = distance.method_1029().method_1021(distance.method_1027() / 2d);
            return vec3d.method_1019(direction);
        }
        return vec3d;
    }
}
