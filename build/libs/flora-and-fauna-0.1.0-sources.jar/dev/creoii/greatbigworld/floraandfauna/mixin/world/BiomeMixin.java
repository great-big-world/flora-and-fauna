package dev.creoii.greatbigworld.floraandfauna.mixin.world;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.llamalad7.mixinextras.sugar.Local;
import dev.creoii.greatbigworld.floraandfauna.client.FloraAndFaunaClient;
import dev.creoii.greatbigworld.floraandfauna.season.Season;
import dev.creoii.greatbigworld.floraandfauna.util.FloraAndFaunaTags;
import net.minecraft.class_1944;
import net.minecraft.class_1959;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_4538;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(class_1959.class)
public class BiomeMixin {
    @WrapOperation(method = "canSetSnow", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/biome/Biome;doesNotSnow(Lnet/minecraft/util/math/BlockPos;)Z"))
    private boolean gbw$modifyCanSetSnowForWinter(class_1959 instance, class_2338 pos, Operation<Boolean> original, @Local(argsOnly = true) class_4538 world) {
        return original.call(instance, pos) && (FloraAndFaunaClient.getCurrentSeason() != Season.WINTER || world.method_23753(pos).method_40220(FloraAndFaunaTags.NOT_AFFECTED_BY_WINTER) && class_2246.field_10477.method_9564().method_26184(world, pos) && pos.method_10264() >= world.method_31607() && pos.method_10264() < world.method_31600() && world.method_8314(class_1944.field_9282, pos) < 10);
    }

    @WrapOperation(method = "canSetIce(Lnet/minecraft/world/WorldView;Lnet/minecraft/util/math/BlockPos;Z)Z", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/biome/Biome;doesNotSnow(Lnet/minecraft/util/math/BlockPos;)Z"))
    private boolean gbw$modifyCanSetIceForWinter(class_1959 instance, class_2338 pos, Operation<Boolean> original, @Local(argsOnly = true) class_4538 world) {
        return original.call(instance, pos) && (FloraAndFaunaClient.getCurrentSeason() != Season.WINTER || world.method_23753(pos).method_40220(FloraAndFaunaTags.NOT_AFFECTED_BY_WINTER));
    }
}
