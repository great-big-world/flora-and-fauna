package dev.creoii.greatbigworld.floraandfauna.mixin.world;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.llamalad7.mixinextras.sugar.Local;
import dev.creoii.greatbigworld.floraandfauna.client.FloraAndFaunaClient;
import dev.creoii.greatbigworld.floraandfauna.season.Season;
import dev.creoii.greatbigworld.floraandfauna.util.FloraAndFaunaTags;
import dev.creoii.greatbigworld.floraandfauna.util.SnowyHelper;
import net.fabricmc.fabric.api.attachment.v1.AttachmentTarget;
import net.minecraft.class_1928;
import net.minecraft.class_1937;
import net.minecraft.class_1944;
import net.minecraft.class_1959;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_2874;
import net.minecraft.class_3218;
import net.minecraft.class_3695;
import net.minecraft.class_4538;
import net.minecraft.class_5269;
import net.minecraft.class_5281;
import net.minecraft.class_5321;
import net.minecraft.class_5455;
import net.minecraft.class_6880;
import net.minecraft.world.*;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.function.Supplier;

@Mixin(class_3218.class)
public abstract class ServerWorldMixin extends class_1937 implements class_5281, AttachmentTarget {
    protected ServerWorldMixin(class_5269 properties, class_5321<class_1937> registryRef, class_5455 registryManager, class_6880<class_2874> dimensionEntry, Supplier<class_3695> profiler, boolean isClient, boolean debugWorld, long biomeAccess, int maxChainedNeighborUpdates) {
        super(properties, registryRef, registryManager, dimensionEntry, profiler, isClient, debugWorld, biomeAccess, maxChainedNeighborUpdates);
    }

    @Inject(method = "tickIceAndSnow", at = @At(value = "INVOKE", target = "Lnet/minecraft/server/world/ServerWorld;setBlockState(Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/block/BlockState;)Z", ordinal = 2), cancellable = true)
    private void gbw$tickSnowyBlocks(class_2338 pos, CallbackInfo ci, @Local(ordinal = 1) class_2338 blockPos) {
        class_2680 state = method_8320(blockPos);
        if (state.method_28498(SnowyHelper.SNOW_LAYERS)) {
            if (state.method_11654(SnowyHelper.SNOW_LAYERS) == 0) {
                int i = state.method_11654(SnowyHelper.SNOW_LAYERS);
                if (i < Math.min(method_8450().method_8356(class_1928.field_40883), 8)) {
                    class_2680 blockState2 = state.method_11657(SnowyHelper.SNOW_LAYERS, i + 1);
                    class_2248.method_9582(state, blockState2, this, blockPos);
                    method_8501(blockPos, blockState2);
                }
            }
            ci.cancel();
        }
    }

    @WrapOperation(method = "tickIceAndSnow", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/biome/Biome;canSetSnow(Lnet/minecraft/world/WorldView;Lnet/minecraft/util/math/BlockPos;)Z"))
    private boolean gbw$modifyCanSetIceForWinter(class_1959 instance, class_4538 world, class_2338 pos, Operation<Boolean> original) {
        return original.call(instance, world, pos) || (FloraAndFaunaClient.getCurrentSeason() == Season.WINTER && !method_23753(pos).method_40220(FloraAndFaunaTags.NOT_AFFECTED_BY_WINTER) && class_2246.field_10477.method_9564().method_26184(world, pos) && pos.method_10264() >= world.method_31607() && pos.method_10264() < world.method_31600() && world.method_8314(class_1944.field_9282, pos) < 10);
    }

    @Redirect(method = "tickIceAndSnow", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/biome/Biome;getPrecipitation(Lnet/minecraft/util/math/BlockPos;)Lnet/minecraft/world/biome/Biome$Precipitation;"))
    private class_1959.class_1963 gbw$modifyTickIceAndSnowForWinter(class_1959 instance, class_2338 pos) {
        return FloraAndFaunaClient.getCurrentSeason() == Season.WINTER && !method_23753(pos).method_40220(FloraAndFaunaTags.NOT_AFFECTED_BY_WINTER) ? class_1959.class_1963.field_9383 : instance.method_48162(pos);
    }
}
