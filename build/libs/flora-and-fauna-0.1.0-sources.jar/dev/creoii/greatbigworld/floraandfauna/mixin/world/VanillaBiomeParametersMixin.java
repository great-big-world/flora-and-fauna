package dev.creoii.greatbigworld.floraandfauna.mixin.world;

import com.mojang.datafixers.util.Pair;
import dev.creoii.greatbigworld.floraandfauna.registry.FloraAndFaunaBiomes;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.function.Consumer;
import net.minecraft.class_1959;
import net.minecraft.class_1972;
import net.minecraft.class_5321;
import net.minecraft.class_6544;
import net.minecraft.class_6554;

@Mixin(class_6554.class)
public abstract class VanillaBiomeParametersMixin {
    @Mutable @Shadow @Final private class_5321<class_1959>[][] uncommonBiomes;
    @Shadow @Final private class_6544.class_6546 defaultParameter;
    @Shadow @Final private class_6544.class_6546 coastContinentalness;
    @Shadow @Final private class_6544.class_6546[] erosionParameters;
    @Shadow @Final private class_6544.class_6546[] temperatureParameters;
    @Shadow @Final private class_6544.class_6546[] humidityParameters;
    @Shadow @Final private class_6544.class_6546 farInlandContinentalness;
    @Shadow @Final private class_6544.class_6546 nearInlandContinentalness;
    @Shadow @Final private class_6544.class_6546 frozenTemperature;
    @Shadow protected abstract void writeBiomeParameters(Consumer<Pair<class_6544.class_4762, class_5321<class_1959>>> parameters, class_6544.class_6546 temperature, class_6544.class_6546 humidity, class_6544.class_6546 continentalness, class_6544.class_6546 erosion, class_6544.class_6546 weirdness, float offset, class_5321<class_1959> biome);

    @SuppressWarnings("unchecked")
    @Inject(method = "<init>", at = @At("TAIL"))
    private void gbw$replaceOldGrowthBirchForest(CallbackInfo ci) {
        uncommonBiomes = new class_5321[][]{{class_1972.field_9453, null, class_1972.field_9454, null, null}, {null, null, null, null, class_1972.field_35119}, {class_1972.field_9455, null, null, class_1972.field_9412, null}, {null, null, class_1972.field_9451, class_1972.field_35118, class_1972.field_9440}, {null, null, null, null, null}};
    }

    @Redirect(method = "writeValleyBiomes", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/biome/source/util/VanillaBiomeParameters;writeBiomeParameters(Ljava/util/function/Consumer;Lnet/minecraft/world/biome/source/util/MultiNoiseUtil$ParameterRange;Lnet/minecraft/world/biome/source/util/MultiNoiseUtil$ParameterRange;Lnet/minecraft/world/biome/source/util/MultiNoiseUtil$ParameterRange;Lnet/minecraft/world/biome/source/util/MultiNoiseUtil$ParameterRange;Lnet/minecraft/world/biome/source/util/MultiNoiseUtil$ParameterRange;FLnet/minecraft/registry/RegistryKey;)V", ordinal = 1))
    private void gbw$writeRiverBiomes1(class_6554 instance, Consumer<Pair<class_6544.class_4762, class_5321<class_1959>>> parameters, class_6544.class_6546 temperature, class_6544.class_6546 humidity, class_6544.class_6546 continentalness, class_6544.class_6546 erosion, class_6544.class_6546 weirdness, float offset, class_5321<class_1959> biome) {
        writeBiomeParameters(parameters, temperatureParameters[4], defaultParameter, coastContinentalness, class_6544.class_6546.method_38123(erosionParameters[0], erosionParameters[1]), weirdness, 0f, weirdness.comp_104() < 0L ? class_1972.field_9419 : FloraAndFaunaBiomes.DESERT_RIVER);
        writeBiomeParameters(parameters, temperatureParameters[3], class_6544.class_6546.method_38123(humidityParameters[3], humidityParameters[4]), coastContinentalness, class_6544.class_6546.method_38123(erosionParameters[0], erosionParameters[1]), weirdness, 0f, weirdness.comp_104() < 0L ? class_1972.field_9419 : FloraAndFaunaBiomes.JUNGLE_RIVER);
        writeBiomeParameters(parameters, temperatureParameters[1], class_6544.class_6546.method_38123(humidityParameters[3], humidityParameters[4]), coastContinentalness, class_6544.class_6546.method_38123(erosionParameters[0], erosionParameters[1]), weirdness, 0f, weirdness.comp_104() < 0L ? class_1972.field_9419 : FloraAndFaunaBiomes.COLD_RIVER);
        writeBiomeParameters(parameters, class_6544.class_6546.method_38123(temperatureParameters[2], temperatureParameters[4]), defaultParameter, coastContinentalness, erosionParameters[6], weirdness, 0f, weirdness.comp_104() < 0L ? class_1972.field_9419 : FloraAndFaunaBiomes.SWAMP_RIVER);
        writeBiomeParameters(parameters, class_6544.class_6546.method_38123(temperatureParameters[1], temperatureParameters[2]), class_6544.class_6546.method_38123(humidityParameters[0], humidityParameters[2]), coastContinentalness, class_6544.class_6546.method_38123(erosionParameters[0], erosionParameters[1]), weirdness, 0f, weirdness.comp_104() < 0L ? class_1972.field_9419 : class_1972.field_9438);
        writeBiomeParameters(parameters, temperatureParameters[3], class_6544.class_6546.method_38123(humidityParameters[0], humidityParameters[2]), coastContinentalness, class_6544.class_6546.method_38123(erosionParameters[0], erosionParameters[1]), weirdness, 0f, weirdness.comp_104() < 0L ? class_1972.field_9419 : class_1972.field_9438);
    }

    @Redirect(method = "writeValleyBiomes", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/biome/source/util/VanillaBiomeParameters;writeBiomeParameters(Ljava/util/function/Consumer;Lnet/minecraft/world/biome/source/util/MultiNoiseUtil$ParameterRange;Lnet/minecraft/world/biome/source/util/MultiNoiseUtil$ParameterRange;Lnet/minecraft/world/biome/source/util/MultiNoiseUtil$ParameterRange;Lnet/minecraft/world/biome/source/util/MultiNoiseUtil$ParameterRange;Lnet/minecraft/world/biome/source/util/MultiNoiseUtil$ParameterRange;FLnet/minecraft/registry/RegistryKey;)V", ordinal = 3))
    private void gbw$writeRiverBiomes3(class_6554 instance, Consumer<Pair<class_6544.class_4762, class_5321<class_1959>>> parameters, class_6544.class_6546 temperature, class_6544.class_6546 humidity, class_6544.class_6546 continentalness, class_6544.class_6546 erosion, class_6544.class_6546 weirdness, float offset, class_5321<class_1959> biome) {
        writeBiomeParameters(parameters, temperatureParameters[4], defaultParameter, nearInlandContinentalness, class_6544.class_6546.method_38123(erosionParameters[0], erosionParameters[1]), weirdness, 0f, FloraAndFaunaBiomes.DESERT_RIVER);
        writeBiomeParameters(parameters, temperatureParameters[3], class_6544.class_6546.method_38123(humidityParameters[3], humidityParameters[4]), nearInlandContinentalness, class_6544.class_6546.method_38123(erosionParameters[0], erosionParameters[1]), weirdness, 0f, FloraAndFaunaBiomes.JUNGLE_RIVER);
        writeBiomeParameters(parameters, temperatureParameters[1], class_6544.class_6546.method_38123(humidityParameters[3], humidityParameters[4]), nearInlandContinentalness, class_6544.class_6546.method_38123(erosionParameters[0], erosionParameters[1]), weirdness, 0f, FloraAndFaunaBiomes.COLD_RIVER);
        writeBiomeParameters(parameters, class_6544.class_6546.method_38123(temperatureParameters[2], temperatureParameters[4]), defaultParameter, nearInlandContinentalness, erosionParameters[6], weirdness, 0f, FloraAndFaunaBiomes.SWAMP_RIVER);
        writeBiomeParameters(parameters, class_6544.class_6546.method_38123(temperatureParameters[1], temperatureParameters[2]), class_6544.class_6546.method_38123(humidityParameters[0], humidityParameters[2]), nearInlandContinentalness, class_6544.class_6546.method_38123(erosionParameters[0], erosionParameters[1]), weirdness, 0f, class_1972.field_9438);
        writeBiomeParameters(parameters, temperatureParameters[3], class_6544.class_6546.method_38123(humidityParameters[0], humidityParameters[2]), nearInlandContinentalness, class_6544.class_6546.method_38123(erosionParameters[0], erosionParameters[1]), weirdness, 0f, class_1972.field_9438);
    }

    @Redirect(method = "writeValleyBiomes", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/biome/source/util/VanillaBiomeParameters;writeBiomeParameters(Ljava/util/function/Consumer;Lnet/minecraft/world/biome/source/util/MultiNoiseUtil$ParameterRange;Lnet/minecraft/world/biome/source/util/MultiNoiseUtil$ParameterRange;Lnet/minecraft/world/biome/source/util/MultiNoiseUtil$ParameterRange;Lnet/minecraft/world/biome/source/util/MultiNoiseUtil$ParameterRange;Lnet/minecraft/world/biome/source/util/MultiNoiseUtil$ParameterRange;FLnet/minecraft/registry/RegistryKey;)V", ordinal = 5))
    private void gbw$writeRiverBiomes5(class_6554 instance, Consumer<Pair<class_6544.class_4762, class_5321<class_1959>>> parameters, class_6544.class_6546 temperature, class_6544.class_6546 humidity, class_6544.class_6546 continentalness, class_6544.class_6546 erosion, class_6544.class_6546 weirdness, float offset, class_5321<class_1959> biome) {
        writeBiomeParameters(parameters, temperatureParameters[4], defaultParameter, class_6544.class_6546.method_38123(coastContinentalness, farInlandContinentalness), class_6544.class_6546.method_38123(erosionParameters[2], erosionParameters[5]), weirdness, 0f, FloraAndFaunaBiomes.DESERT_RIVER);
        writeBiomeParameters(parameters, temperatureParameters[3], class_6544.class_6546.method_38123(humidityParameters[3], humidityParameters[4]), class_6544.class_6546.method_38123(coastContinentalness, farInlandContinentalness), class_6544.class_6546.method_38123(erosionParameters[2], erosionParameters[5]), weirdness, 0f, FloraAndFaunaBiomes.JUNGLE_RIVER);
        writeBiomeParameters(parameters, temperatureParameters[1], class_6544.class_6546.method_38123(humidityParameters[3], humidityParameters[4]), class_6544.class_6546.method_38123(coastContinentalness, farInlandContinentalness), class_6544.class_6546.method_38123(erosionParameters[2], erosionParameters[5]), weirdness, 0f, FloraAndFaunaBiomes.COLD_RIVER);
        writeBiomeParameters(parameters, class_6544.class_6546.method_38123(temperatureParameters[2], temperatureParameters[4]), defaultParameter, class_6544.class_6546.method_38123(coastContinentalness, farInlandContinentalness), erosionParameters[6], weirdness, 0f, FloraAndFaunaBiomes.SWAMP_RIVER);
        writeBiomeParameters(parameters, class_6544.class_6546.method_38123(temperatureParameters[1], temperatureParameters[2]), class_6544.class_6546.method_38123(humidityParameters[0], humidityParameters[2]), class_6544.class_6546.method_38123(coastContinentalness, farInlandContinentalness), class_6544.class_6546.method_38123(erosionParameters[2], erosionParameters[5]), weirdness, 0f, class_1972.field_9438);
        writeBiomeParameters(parameters, temperatureParameters[3], class_6544.class_6546.method_38123(humidityParameters[0], humidityParameters[2]), class_6544.class_6546.method_38123(coastContinentalness, farInlandContinentalness), class_6544.class_6546.method_38123(erosionParameters[2], erosionParameters[5]), weirdness, 0f, class_1972.field_9438);
    }

    @Redirect(method = "writeValleyBiomes", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/biome/source/util/VanillaBiomeParameters;writeBiomeParameters(Ljava/util/function/Consumer;Lnet/minecraft/world/biome/source/util/MultiNoiseUtil$ParameterRange;Lnet/minecraft/world/biome/source/util/MultiNoiseUtil$ParameterRange;Lnet/minecraft/world/biome/source/util/MultiNoiseUtil$ParameterRange;Lnet/minecraft/world/biome/source/util/MultiNoiseUtil$ParameterRange;Lnet/minecraft/world/biome/source/util/MultiNoiseUtil$ParameterRange;FLnet/minecraft/registry/RegistryKey;)V", ordinal = 7))
    private void gbw$writeRiverBiomes7(class_6554 instance, Consumer<Pair<class_6544.class_4762, class_5321<class_1959>>> parameters, class_6544.class_6546 temperature, class_6544.class_6546 humidity, class_6544.class_6546 continentalness, class_6544.class_6546 erosion, class_6544.class_6546 weirdness, float offset, class_5321<class_1959> biome) {
        writeBiomeParameters(parameters, temperatureParameters[4], defaultParameter, coastContinentalness, erosionParameters[6], weirdness, 0f, FloraAndFaunaBiomes.DESERT_RIVER);
        writeBiomeParameters(parameters, temperatureParameters[3], class_6544.class_6546.method_38123(humidityParameters[3], humidityParameters[4]), coastContinentalness, erosionParameters[6], weirdness, 0f, FloraAndFaunaBiomes.JUNGLE_RIVER);
        writeBiomeParameters(parameters, temperatureParameters[1], class_6544.class_6546.method_38123(humidityParameters[3], humidityParameters[4]), coastContinentalness, erosionParameters[6], weirdness, 0f, FloraAndFaunaBiomes.COLD_RIVER);
        writeBiomeParameters(parameters, class_6544.class_6546.method_38123(temperatureParameters[2], temperatureParameters[4]), defaultParameter, coastContinentalness, erosionParameters[6], weirdness, 0f, FloraAndFaunaBiomes.SWAMP_RIVER);
        writeBiomeParameters(parameters, class_6544.class_6546.method_38123(temperatureParameters[1], temperatureParameters[2]), class_6544.class_6546.method_38123(humidityParameters[0], humidityParameters[2]), coastContinentalness, erosionParameters[6], weirdness, 0f, class_1972.field_9438);
        writeBiomeParameters(parameters, temperatureParameters[3], class_6544.class_6546.method_38123(humidityParameters[0], humidityParameters[2]), coastContinentalness, erosionParameters[6], weirdness, 0f, class_1972.field_9438);
    }

    @Redirect(method = "writeValleyBiomes", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/biome/source/util/VanillaBiomeParameters;writeBiomeParameters(Ljava/util/function/Consumer;Lnet/minecraft/world/biome/source/util/MultiNoiseUtil$ParameterRange;Lnet/minecraft/world/biome/source/util/MultiNoiseUtil$ParameterRange;Lnet/minecraft/world/biome/source/util/MultiNoiseUtil$ParameterRange;Lnet/minecraft/world/biome/source/util/MultiNoiseUtil$ParameterRange;Lnet/minecraft/world/biome/source/util/MultiNoiseUtil$ParameterRange;FLnet/minecraft/registry/RegistryKey;)V", ordinal = 0))
    private void gbw$writeRiverBiomes0(class_6554 instance, Consumer<Pair<class_6544.class_4762, class_5321<class_1959>>> parameters, class_6544.class_6546 temperature, class_6544.class_6546 humidity, class_6544.class_6546 continentalness, class_6544.class_6546 erosion, class_6544.class_6546 weirdness, float offset, class_5321<class_1959> biome) {
        writeBiomeParameters(parameters, frozenTemperature, class_6544.class_6546.method_38123(temperatureParameters[0], temperatureParameters[3]), coastContinentalness, class_6544.class_6546.method_38123(erosionParameters[0], erosionParameters[1]), weirdness, 0f, weirdness.comp_104() < 0L ? class_1972.field_9419 : class_1972.field_9463);
        writeBiomeParameters(parameters, frozenTemperature, humidityParameters[4], coastContinentalness, class_6544.class_6546.method_38123(erosionParameters[0], erosionParameters[1]), weirdness, 0f, weirdness.comp_104() < 0L ? class_1972.field_9419 : FloraAndFaunaBiomes.COLD_RIVER);
    }

    @Redirect(method = "writeValleyBiomes", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/biome/source/util/VanillaBiomeParameters;writeBiomeParameters(Ljava/util/function/Consumer;Lnet/minecraft/world/biome/source/util/MultiNoiseUtil$ParameterRange;Lnet/minecraft/world/biome/source/util/MultiNoiseUtil$ParameterRange;Lnet/minecraft/world/biome/source/util/MultiNoiseUtil$ParameterRange;Lnet/minecraft/world/biome/source/util/MultiNoiseUtil$ParameterRange;Lnet/minecraft/world/biome/source/util/MultiNoiseUtil$ParameterRange;FLnet/minecraft/registry/RegistryKey;)V", ordinal = 2))
    private void gbw$writeRiverBiomes2(class_6554 instance, Consumer<Pair<class_6544.class_4762, class_5321<class_1959>>> parameters, class_6544.class_6546 temperature, class_6544.class_6546 humidity, class_6544.class_6546 continentalness, class_6544.class_6546 erosion, class_6544.class_6546 weirdness, float offset, class_5321<class_1959> biome) {
        writeBiomeParameters(parameters, frozenTemperature, class_6544.class_6546.method_38123(temperatureParameters[0], temperatureParameters[3]), nearInlandContinentalness, class_6544.class_6546.method_38123(erosionParameters[0], erosionParameters[1]), weirdness, 0f, class_1972.field_9463);
        writeBiomeParameters(parameters, frozenTemperature, humidityParameters[4], nearInlandContinentalness, class_6544.class_6546.method_38123(erosionParameters[0], erosionParameters[1]), weirdness, 0f, FloraAndFaunaBiomes.COLD_RIVER);
    }

    @Redirect(method = "writeValleyBiomes", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/biome/source/util/VanillaBiomeParameters;writeBiomeParameters(Ljava/util/function/Consumer;Lnet/minecraft/world/biome/source/util/MultiNoiseUtil$ParameterRange;Lnet/minecraft/world/biome/source/util/MultiNoiseUtil$ParameterRange;Lnet/minecraft/world/biome/source/util/MultiNoiseUtil$ParameterRange;Lnet/minecraft/world/biome/source/util/MultiNoiseUtil$ParameterRange;Lnet/minecraft/world/biome/source/util/MultiNoiseUtil$ParameterRange;FLnet/minecraft/registry/RegistryKey;)V", ordinal = 4))
    private void gbw$writeRiverBiomes4(class_6554 instance, Consumer<Pair<class_6544.class_4762, class_5321<class_1959>>> parameters, class_6544.class_6546 temperature, class_6544.class_6546 humidity, class_6544.class_6546 continentalness, class_6544.class_6546 erosion, class_6544.class_6546 weirdness, float offset, class_5321<class_1959> biome) {
        writeBiomeParameters(parameters, frozenTemperature, class_6544.class_6546.method_38123(temperatureParameters[0], temperatureParameters[3]), class_6544.class_6546.method_38123(coastContinentalness, farInlandContinentalness), class_6544.class_6546.method_38123(erosionParameters[2], erosionParameters[5]), weirdness, 0f, class_1972.field_9463);
        writeBiomeParameters(parameters, frozenTemperature, humidityParameters[4], class_6544.class_6546.method_38123(coastContinentalness, farInlandContinentalness), class_6544.class_6546.method_38123(erosionParameters[2], erosionParameters[5]), weirdness, 0f, FloraAndFaunaBiomes.COLD_RIVER);
    }

    @Redirect(method = "writeValleyBiomes", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/biome/source/util/VanillaBiomeParameters;writeBiomeParameters(Ljava/util/function/Consumer;Lnet/minecraft/world/biome/source/util/MultiNoiseUtil$ParameterRange;Lnet/minecraft/world/biome/source/util/MultiNoiseUtil$ParameterRange;Lnet/minecraft/world/biome/source/util/MultiNoiseUtil$ParameterRange;Lnet/minecraft/world/biome/source/util/MultiNoiseUtil$ParameterRange;Lnet/minecraft/world/biome/source/util/MultiNoiseUtil$ParameterRange;FLnet/minecraft/registry/RegistryKey;)V", ordinal = 6))
    private void gbw$writeRiverBiomes6(class_6554 instance, Consumer<Pair<class_6544.class_4762, class_5321<class_1959>>> parameters, class_6544.class_6546 temperature, class_6544.class_6546 humidity, class_6544.class_6546 continentalness, class_6544.class_6546 erosion, class_6544.class_6546 weirdness, float offset, class_5321<class_1959> biome) {
        writeBiomeParameters(parameters, frozenTemperature, class_6544.class_6546.method_38123(temperatureParameters[0], temperatureParameters[3]), coastContinentalness, erosionParameters[6], weirdness, 0f, class_1972.field_9463);
        writeBiomeParameters(parameters, frozenTemperature, humidityParameters[4], coastContinentalness, erosionParameters[6], weirdness, 0f, FloraAndFaunaBiomes.COLD_RIVER);
    }
}
