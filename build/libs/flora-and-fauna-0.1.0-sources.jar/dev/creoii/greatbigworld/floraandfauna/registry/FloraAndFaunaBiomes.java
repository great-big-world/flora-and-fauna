package dev.creoii.greatbigworld.floraandfauna.registry;

import dev.creoii.greatbigworld.floraandfauna.FloraAndFauna;
import net.minecraft.class_1959;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7924;

public final class FloraAndFaunaBiomes {
    public static final class_5321<class_1959> COLD_RIVER = class_5321.method_29179(class_7924.field_41236, new class_2960(FloraAndFauna.NAMESPACE, "cold_river"));
    public static final class_5321<class_1959> DESERT_RIVER = class_5321.method_29179(class_7924.field_41236, new class_2960(FloraAndFauna.NAMESPACE, "desert_river"));
    public static final class_5321<class_1959> JUNGLE_RIVER = class_5321.method_29179(class_7924.field_41236, new class_2960(FloraAndFauna.NAMESPACE, "jungle_river"));
    public static final class_5321<class_1959> SWAMP_RIVER = class_5321.method_29179(class_7924.field_41236, new class_2960(FloraAndFauna.NAMESPACE, "swamp_river"));
}
