package dev.creoii.greatbigworld.floraandfauna.registry;

import com.mojang.serialization.Lifecycle;
import dev.creoii.greatbigworld.floraandfauna.FloraAndFauna;
import dev.creoii.greatbigworld.floraandfauna.block.AlgaeBlock;
import dev.creoii.greatbigworld.floraandfauna.block.HollowLogBlock;
import dev.creoii.greatbigworld.floraandfauna.block.MossCarpetBlock;
import dev.creoii.greatbigworld.floraandfauna.util.ColorHelper;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.blockrenderlayer.v1.BlockRenderLayerMap;
import net.fabricmc.fabric.api.client.rendering.v1.ColorProviderRegistry;
import net.fabricmc.fabric.api.object.builder.v1.block.FabricBlockSettings;
import net.fabricmc.fabric.api.registry.FlammableBlockRegistry;
import net.fabricmc.fabric.api.registry.StrippableBlockRegistry;
import net.minecraft.block.*;
import net.minecraft.class_1163;
import net.minecraft.class_1294;
import net.minecraft.class_1921;
import net.minecraft.class_1933;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2320;
import net.minecraft.class_2348;
import net.minecraft.class_2356;
import net.minecraft.class_2362;
import net.minecraft.class_2378;
import net.minecraft.class_2493;
import net.minecraft.class_2526;
import net.minecraft.class_2756;
import net.minecraft.class_2960;
import net.minecraft.class_3620;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import net.minecraft.registry.*;

public final class FloraAndFaunaBlocks {
    public static final class_2248 HUMUS = new class_2493(FabricBlockSettings.method_9630(class_2246.field_10219).method_31710(class_3620.field_15992));
    public static final class_2248 MOSS_CARPET = new MossCarpetBlock(FabricBlockSettings.method_9630(class_2246.field_28680));
    public static final class_2248 TROPICAL_FERN = new class_2526(FabricBlockSettings.method_9630(class_2246.field_10112));
    public static final class_2248 LARGE_TROPICAL_FERN = new class_2320(FabricBlockSettings.method_9630(class_2246.field_10313));
    public static final class_2248 POTTED_TROPICAL_FERN = new class_2362(TROPICAL_FERN, FabricBlockSettings.method_9630(class_2246.field_10495));
    public static final class_2248 RED_HIBISCUS = new class_2356(class_1294.field_5916, 0, FabricBlockSettings.method_9630(class_2246.field_10182));
    public static final class_2248 ORANGE_HIBISCUS = new class_2356(class_1294.field_5916, 0, FabricBlockSettings.method_9630(class_2246.field_10182));
    public static final class_2248 YELLOW_HIBISCUS = new class_2356(class_1294.field_5916, 0, FabricBlockSettings.method_9630(class_2246.field_10182));
    public static final class_2248 BLUE_HIBISCUS = new class_2356(class_1294.field_5916, 0, FabricBlockSettings.method_9630(class_2246.field_10182));
    public static final class_2248 PINK_HIBISCUS = new class_2356(class_1294.field_5916, 0, FabricBlockSettings.method_9630(class_2246.field_10182));
    public static final class_2248 PURPLE_HIBISCUS = new class_2356(class_1294.field_5916, 0, FabricBlockSettings.method_9630(class_2246.field_10182));
    public static final class_2248 BLACK_HIBISCUS = new class_2356(class_1294.field_5916, 0, FabricBlockSettings.method_9630(class_2246.field_10182));
    public static final class_2248 WHITE_HIBISCUS = new class_2356(class_1294.field_5916, 0, FabricBlockSettings.method_9630(class_2246.field_10182));
    public static final class_2248 POTTED_RED_HIBISCUS = new class_2362(RED_HIBISCUS, FabricBlockSettings.method_9630(class_2246.field_10495));
    public static final class_2248 POTTED_ORANGE_HIBISCUS = new class_2362(ORANGE_HIBISCUS, FabricBlockSettings.method_9630(class_2246.field_10495));
    public static final class_2248 POTTED_YELLOW_HIBISCUS = new class_2362(YELLOW_HIBISCUS, FabricBlockSettings.method_9630(class_2246.field_10495));
    public static final class_2248 POTTED_BLUE_HIBISCUS = new class_2362(BLUE_HIBISCUS, FabricBlockSettings.method_9630(class_2246.field_10495));
    public static final class_2248 POTTED_PINK_HIBISCUS = new class_2362(PINK_HIBISCUS, FabricBlockSettings.method_9630(class_2246.field_10495));
    public static final class_2248 POTTED_PURPLE_HIBISCUS = new class_2362(PURPLE_HIBISCUS, FabricBlockSettings.method_9630(class_2246.field_10495));
    public static final class_2248 POTTED_BLACK_HIBISCUS = new class_2362(BLACK_HIBISCUS, FabricBlockSettings.method_9630(class_2246.field_10495));
    public static final class_2248 POTTED_WHITE_HIBISCUS = new class_2362(WHITE_HIBISCUS, FabricBlockSettings.method_9630(class_2246.field_10495));
    public static final class_2248 HOLLOW_OAK_LOG = new HollowLogBlock(FabricBlockSettings.method_9630(class_2246.field_10431));
    public static final class_2248 HOLLOW_SPRUCE_LOG = new HollowLogBlock(FabricBlockSettings.method_9630(class_2246.field_10037));
    public static final class_2248 HOLLOW_BIRCH_LOG = new HollowLogBlock(FabricBlockSettings.method_9630(class_2246.field_10511));
    public static final class_2248 HOLLOW_JUNGLE_LOG = new HollowLogBlock(FabricBlockSettings.method_9630(class_2246.field_10306));
    public static final class_2248 HOLLOW_DARK_OAK_LOG = new HollowLogBlock(FabricBlockSettings.method_9630(class_2246.field_10010));
    public static final class_2248 HOLLOW_ACACIA_LOG = new HollowLogBlock(FabricBlockSettings.method_9630(class_2246.field_10533));
    public static final class_2248 HOLLOW_MANGROVE_LOG = new HollowLogBlock(FabricBlockSettings.method_9630(class_2246.field_37545));
    public static final class_2248 HOLLOW_CHERRY_LOG = new HollowLogBlock(FabricBlockSettings.method_9630(class_2246.field_42729));
    public static final class_2248 HOLLOW_WARPED_STEM = new HollowLogBlock(FabricBlockSettings.method_9630(class_2246.field_22111));
    public static final class_2248 HOLLOW_CRIMSON_STEM = new HollowLogBlock(FabricBlockSettings.method_9630(class_2246.field_22118));
    public static final class_2248 STRIPPED_HOLLOW_OAK_LOG = new HollowLogBlock(FabricBlockSettings.method_9630(class_2246.field_10519));
    public static final class_2248 STRIPPED_HOLLOW_SPRUCE_LOG = new HollowLogBlock(FabricBlockSettings.method_9630(class_2246.field_10436));
    public static final class_2248 STRIPPED_HOLLOW_BIRCH_LOG = new HollowLogBlock(FabricBlockSettings.method_9630(class_2246.field_10366));
    public static final class_2248 STRIPPED_HOLLOW_JUNGLE_LOG = new HollowLogBlock(FabricBlockSettings.method_9630(class_2246.field_10254));
    public static final class_2248 STRIPPED_HOLLOW_DARK_OAK_LOG = new HollowLogBlock(FabricBlockSettings.method_9630(class_2246.field_10244));
    public static final class_2248 STRIPPED_HOLLOW_ACACIA_LOG = new HollowLogBlock(FabricBlockSettings.method_9630(class_2246.field_10622));
    public static final class_2248 STRIPPED_HOLLOW_MANGROVE_LOG = new HollowLogBlock(FabricBlockSettings.method_9630(class_2246.field_37548));
    public static final class_2248 STRIPPED_HOLLOW_CHERRY_LOG = new HollowLogBlock(FabricBlockSettings.method_9630(class_2246.field_42732));
    public static final class_2248 STRIPPED_HOLLOW_WARPED_STEM = new HollowLogBlock(FabricBlockSettings.method_9630(class_2246.field_22112));
    public static final class_2248 STRIPPED_HOLLOW_CRIMSON_STEM = new HollowLogBlock(FabricBlockSettings.method_9630(class_2246.field_22119));
    public static final class_2248 ALGAE = new AlgaeBlock(FabricBlockSettings.method_9630(class_2246.field_10588));

    public static void register() {
        final class_2348<class_2248> blocks = (class_2348<class_2248>) class_7923.field_41175;

        class_2378.method_10230(class_7923.field_41175, new class_2960(FloraAndFauna.NAMESPACE, "humus"), HUMUS);
        blocks.method_46744(blocks.method_10206(class_2246.field_28680), class_5321.method_29179(class_7924.field_41254, new class_2960("moss_carpet")), MOSS_CARPET, Lifecycle.stable());

        class_2378.method_10230(class_7923.field_41175, new class_2960(FloraAndFauna.NAMESPACE, "tropical_fern"), TROPICAL_FERN);
        class_2378.method_10230(class_7923.field_41175, new class_2960(FloraAndFauna.NAMESPACE, "large_tropical_fern"), LARGE_TROPICAL_FERN);
        class_2378.method_10230(class_7923.field_41175, new class_2960(FloraAndFauna.NAMESPACE, "potted_tropical_fern"), POTTED_TROPICAL_FERN);

        class_2378.method_10230(class_7923.field_41175, new class_2960(FloraAndFauna.NAMESPACE, "red_hibiscus"), RED_HIBISCUS);
        class_2378.method_10230(class_7923.field_41175, new class_2960(FloraAndFauna.NAMESPACE, "orange_hibiscus"), ORANGE_HIBISCUS);
        class_2378.method_10230(class_7923.field_41175, new class_2960(FloraAndFauna.NAMESPACE, "yellow_hibiscus"), YELLOW_HIBISCUS);
        class_2378.method_10230(class_7923.field_41175, new class_2960(FloraAndFauna.NAMESPACE, "blue_hibiscus"), BLUE_HIBISCUS);
        class_2378.method_10230(class_7923.field_41175, new class_2960(FloraAndFauna.NAMESPACE, "pink_hibiscus"), PINK_HIBISCUS);
        class_2378.method_10230(class_7923.field_41175, new class_2960(FloraAndFauna.NAMESPACE, "purple_hibiscus"), PURPLE_HIBISCUS);
        class_2378.method_10230(class_7923.field_41175, new class_2960(FloraAndFauna.NAMESPACE, "black_hibiscus"), BLACK_HIBISCUS);
        class_2378.method_10230(class_7923.field_41175, new class_2960(FloraAndFauna.NAMESPACE, "white_hibiscus"), WHITE_HIBISCUS);
        class_2378.method_10230(class_7923.field_41175, new class_2960(FloraAndFauna.NAMESPACE, "potted_red_hibiscus"), POTTED_RED_HIBISCUS);
        class_2378.method_10230(class_7923.field_41175, new class_2960(FloraAndFauna.NAMESPACE, "potted_orange_hibiscus"), POTTED_ORANGE_HIBISCUS);
        class_2378.method_10230(class_7923.field_41175, new class_2960(FloraAndFauna.NAMESPACE, "potted_yellow_hibiscus"), POTTED_YELLOW_HIBISCUS);
        class_2378.method_10230(class_7923.field_41175, new class_2960(FloraAndFauna.NAMESPACE, "potted_blue_hibiscus"), POTTED_BLUE_HIBISCUS);
        class_2378.method_10230(class_7923.field_41175, new class_2960(FloraAndFauna.NAMESPACE, "potted_pink_hibiscus"), POTTED_PINK_HIBISCUS);
        class_2378.method_10230(class_7923.field_41175, new class_2960(FloraAndFauna.NAMESPACE, "potted_purple_hibiscus"), POTTED_PURPLE_HIBISCUS);
        class_2378.method_10230(class_7923.field_41175, new class_2960(FloraAndFauna.NAMESPACE, "potted_black_hibiscus"), POTTED_BLACK_HIBISCUS);
        class_2378.method_10230(class_7923.field_41175, new class_2960(FloraAndFauna.NAMESPACE, "potted_white_hibiscus"), POTTED_WHITE_HIBISCUS);

        class_2378.method_10230(class_7923.field_41175, new class_2960(FloraAndFauna.NAMESPACE, "hollow_oak_log"), HOLLOW_OAK_LOG);
        class_2378.method_10230(class_7923.field_41175, new class_2960(FloraAndFauna.NAMESPACE, "hollow_spruce_log"), HOLLOW_SPRUCE_LOG);
        class_2378.method_10230(class_7923.field_41175, new class_2960(FloraAndFauna.NAMESPACE, "hollow_birch_log"), HOLLOW_BIRCH_LOG);
        class_2378.method_10230(class_7923.field_41175, new class_2960(FloraAndFauna.NAMESPACE, "hollow_jungle_log"), HOLLOW_JUNGLE_LOG);
        class_2378.method_10230(class_7923.field_41175, new class_2960(FloraAndFauna.NAMESPACE, "hollow_dark_oak_log"), HOLLOW_DARK_OAK_LOG);
        class_2378.method_10230(class_7923.field_41175, new class_2960(FloraAndFauna.NAMESPACE, "hollow_acacia_log"), HOLLOW_ACACIA_LOG);
        class_2378.method_10230(class_7923.field_41175, new class_2960(FloraAndFauna.NAMESPACE, "hollow_mangrove_log"), HOLLOW_MANGROVE_LOG);
        class_2378.method_10230(class_7923.field_41175, new class_2960(FloraAndFauna.NAMESPACE, "hollow_cherry_log"), HOLLOW_CHERRY_LOG);
        class_2378.method_10230(class_7923.field_41175, new class_2960(FloraAndFauna.NAMESPACE, "hollow_warped_stem"), HOLLOW_WARPED_STEM);
        class_2378.method_10230(class_7923.field_41175, new class_2960(FloraAndFauna.NAMESPACE, "hollow_crimson_stem"), HOLLOW_CRIMSON_STEM);
        class_2378.method_10230(class_7923.field_41175, new class_2960(FloraAndFauna.NAMESPACE, "stripped_hollow_oak_log"), STRIPPED_HOLLOW_OAK_LOG);
        class_2378.method_10230(class_7923.field_41175, new class_2960(FloraAndFauna.NAMESPACE, "stripped_hollow_spruce_log"), STRIPPED_HOLLOW_SPRUCE_LOG);
        class_2378.method_10230(class_7923.field_41175, new class_2960(FloraAndFauna.NAMESPACE, "stripped_hollow_birch_log"), STRIPPED_HOLLOW_BIRCH_LOG);
        class_2378.method_10230(class_7923.field_41175, new class_2960(FloraAndFauna.NAMESPACE, "stripped_hollow_jungle_log"), STRIPPED_HOLLOW_JUNGLE_LOG);
        class_2378.method_10230(class_7923.field_41175, new class_2960(FloraAndFauna.NAMESPACE, "stripped_hollow_dark_oak_log"), STRIPPED_HOLLOW_DARK_OAK_LOG);
        class_2378.method_10230(class_7923.field_41175, new class_2960(FloraAndFauna.NAMESPACE, "stripped_hollow_acacia_log"), STRIPPED_HOLLOW_ACACIA_LOG);
        class_2378.method_10230(class_7923.field_41175, new class_2960(FloraAndFauna.NAMESPACE, "stripped_hollow_mangrove_log"), STRIPPED_HOLLOW_MANGROVE_LOG);
        class_2378.method_10230(class_7923.field_41175, new class_2960(FloraAndFauna.NAMESPACE, "stripped_hollow_cherry_log"), STRIPPED_HOLLOW_CHERRY_LOG);
        class_2378.method_10230(class_7923.field_41175, new class_2960(FloraAndFauna.NAMESPACE, "stripped_hollow_warped_stem"), STRIPPED_HOLLOW_WARPED_STEM);
        class_2378.method_10230(class_7923.field_41175, new class_2960(FloraAndFauna.NAMESPACE, "stripped_hollow_crimson_stem"), STRIPPED_HOLLOW_CRIMSON_STEM);

        class_2378.method_10230(class_7923.field_41175, new class_2960(FloraAndFauna.NAMESPACE, "algae"), ALGAE);

        FlammableBlockRegistry.getDefaultInstance().add(TROPICAL_FERN, 60, 100);
        FlammableBlockRegistry.getDefaultInstance().add(LARGE_TROPICAL_FERN, 60, 100);

        FlammableBlockRegistry.getDefaultInstance().add(RED_HIBISCUS, 60, 100);
        FlammableBlockRegistry.getDefaultInstance().add(ORANGE_HIBISCUS, 60, 100);
        FlammableBlockRegistry.getDefaultInstance().add(YELLOW_HIBISCUS, 60, 100);
        FlammableBlockRegistry.getDefaultInstance().add(BLUE_HIBISCUS, 60, 100);
        FlammableBlockRegistry.getDefaultInstance().add(PINK_HIBISCUS, 60, 100);
        FlammableBlockRegistry.getDefaultInstance().add(PURPLE_HIBISCUS, 60, 100);
        FlammableBlockRegistry.getDefaultInstance().add(BLACK_HIBISCUS, 60, 100);
        FlammableBlockRegistry.getDefaultInstance().add(WHITE_HIBISCUS, 60, 100);

        FlammableBlockRegistry.getDefaultInstance().add(HOLLOW_OAK_LOG, 5, 5);
        FlammableBlockRegistry.getDefaultInstance().add(HOLLOW_SPRUCE_LOG, 5, 5);
        FlammableBlockRegistry.getDefaultInstance().add(HOLLOW_BIRCH_LOG, 5, 5);
        FlammableBlockRegistry.getDefaultInstance().add(HOLLOW_JUNGLE_LOG, 5, 5);
        FlammableBlockRegistry.getDefaultInstance().add(HOLLOW_DARK_OAK_LOG, 5, 5);
        FlammableBlockRegistry.getDefaultInstance().add(HOLLOW_ACACIA_LOG, 5, 5);
        FlammableBlockRegistry.getDefaultInstance().add(HOLLOW_MANGROVE_LOG, 5, 5);
        FlammableBlockRegistry.getDefaultInstance().add(HOLLOW_CHERRY_LOG, 5, 5);
        FlammableBlockRegistry.getDefaultInstance().add(STRIPPED_HOLLOW_OAK_LOG, 5, 5);
        FlammableBlockRegistry.getDefaultInstance().add(STRIPPED_HOLLOW_SPRUCE_LOG, 5, 5);
        FlammableBlockRegistry.getDefaultInstance().add(STRIPPED_HOLLOW_BIRCH_LOG, 5, 5);
        FlammableBlockRegistry.getDefaultInstance().add(STRIPPED_HOLLOW_JUNGLE_LOG, 5, 5);
        FlammableBlockRegistry.getDefaultInstance().add(STRIPPED_HOLLOW_DARK_OAK_LOG, 5, 5);
        FlammableBlockRegistry.getDefaultInstance().add(STRIPPED_HOLLOW_ACACIA_LOG, 5, 5);
        FlammableBlockRegistry.getDefaultInstance().add(STRIPPED_HOLLOW_MANGROVE_LOG, 5, 5);
        FlammableBlockRegistry.getDefaultInstance().add(STRIPPED_HOLLOW_CHERRY_LOG, 5, 5);

        StrippableBlockRegistry.register(HOLLOW_OAK_LOG, STRIPPED_HOLLOW_OAK_LOG);
        StrippableBlockRegistry.register(HOLLOW_SPRUCE_LOG, STRIPPED_HOLLOW_SPRUCE_LOG);
        StrippableBlockRegistry.register(HOLLOW_BIRCH_LOG, STRIPPED_HOLLOW_BIRCH_LOG);
        StrippableBlockRegistry.register(HOLLOW_JUNGLE_LOG, STRIPPED_HOLLOW_JUNGLE_LOG);
        StrippableBlockRegistry.register(HOLLOW_ACACIA_LOG, STRIPPED_HOLLOW_ACACIA_LOG);
        StrippableBlockRegistry.register(HOLLOW_DARK_OAK_LOG, STRIPPED_HOLLOW_DARK_OAK_LOG);
        StrippableBlockRegistry.register(HOLLOW_MANGROVE_LOG, STRIPPED_HOLLOW_MANGROVE_LOG);
        StrippableBlockRegistry.register(HOLLOW_CHERRY_LOG, STRIPPED_HOLLOW_CHERRY_LOG);
        StrippableBlockRegistry.register(HOLLOW_WARPED_STEM, STRIPPED_HOLLOW_WARPED_STEM);
        StrippableBlockRegistry.register(HOLLOW_CRIMSON_STEM, STRIPPED_HOLLOW_CRIMSON_STEM);
    }

    @Environment(EnvType.CLIENT)
    public static void registerClient() {
        BlockRenderLayerMap.INSTANCE.putBlocks(class_1921.method_23581(),
                TROPICAL_FERN, LARGE_TROPICAL_FERN, POTTED_TROPICAL_FERN,
                RED_HIBISCUS, ORANGE_HIBISCUS, YELLOW_HIBISCUS, BLUE_HIBISCUS, PINK_HIBISCUS, PURPLE_HIBISCUS, BLACK_HIBISCUS, WHITE_HIBISCUS,
                POTTED_RED_HIBISCUS, POTTED_ORANGE_HIBISCUS, POTTED_YELLOW_HIBISCUS, POTTED_BLUE_HIBISCUS, POTTED_PINK_HIBISCUS, POTTED_PURPLE_HIBISCUS, POTTED_BLACK_HIBISCUS, POTTED_WHITE_HIBISCUS,
                ALGAE
        );

        ColorProviderRegistry.BLOCK.register((state, world, pos, tintIndex) -> {
            return ColorHelper.add(world != null && pos != null ? class_1163.method_4962(world, state.method_11654(class_2320.field_10929) == class_2756.field_12609 ? pos.method_10074() : pos) : class_1933.method_49724(), 75, 75, 0);
        }, LARGE_TROPICAL_FERN);
        ColorProviderRegistry.BLOCK.register((state, world, pos, tintIndex) -> {
            return ColorHelper.add(world != null && pos != null ? class_1163.method_4962(world, pos) : class_1933.method_49724(), 75, 75, 0);
        }, TROPICAL_FERN, POTTED_TROPICAL_FERN);
    }
}
