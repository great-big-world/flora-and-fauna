package dev.creoii.greatbigworld.floraandfauna.registry;

import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import dev.creoii.greatbigworld.floraandfauna.season.Season;
import dev.creoii.greatbigworld.floraandfauna.season.SeasonManager;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2561;
import org.apache.commons.lang3.StringUtils;

public final class FloraAndFaunaCommands {
    public static void register() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
            dispatcher.register(LiteralArgumentBuilder.<class_2168>literal("season")
                    .requires(source -> source.method_9259(2))
                    .executes(context -> {
                        context.getSource().method_9226(() -> class_2561.method_43470("The current season is " + StringUtils.capitalize(SeasonManager.getInstance(context.getSource().method_9211()).getCurrentSeason().name().toLowerCase())), false);
                        return 1;
                    })
                    .then(class_2170.method_9244("season", StringArgumentType.string())
                            .suggests((context1, builder) -> {
                                for (Season season : Season.values()) {
                                    builder.suggest(season.name().toLowerCase());
                                }
                                return builder.buildFuture();
                            })
                            .executes(context -> {
                                String season = context.getArgument("season", String.class);
                                SeasonManager.getInstance(context.getSource().method_9211()).setCurrentSeason(context.getSource().method_9225(), Season.valueOf(season.toUpperCase()), false);
                                context.getSource().method_9226(() -> class_2561.method_43470("Set season to " + season), true);
                                return 1;
                            })
                    )
            );
        });
    }
}
