package dev.creoii.greatbigworld.floraandfauna.registry;

import dev.creoii.greatbigworld.floraandfauna.FloraAndFauna;
import dev.creoii.greatbigworld.floraandfauna.advancement.DuckFollowChickenCriteria;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

public final class FloraAndFaunaCriteria {
    public static final DuckFollowChickenCriteria DUCK_FOLLOW_CHICKEN = new DuckFollowChickenCriteria();

    public static void register() {
        class_2378.method_10230(class_7923.field_47496, new class_2960(FloraAndFauna.NAMESPACE, "duck_follow_parent"), DUCK_FOLLOW_CHICKEN);
    }
}
