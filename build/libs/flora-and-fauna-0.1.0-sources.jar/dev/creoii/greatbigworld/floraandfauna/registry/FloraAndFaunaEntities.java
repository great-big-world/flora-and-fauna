package dev.creoii.greatbigworld.floraandfauna.registry;

import dev.creoii.greatbigworld.floraandfauna.FloraAndFauna;
import dev.creoii.greatbigworld.floraandfauna.client.render.DuckEntityRenderer;
import dev.creoii.greatbigworld.floraandfauna.entity.DuckEntity;
import dev.creoii.greatbigworld.floraandfauna.util.FloraAndFaunaEntityModelLayers;
import dev.creoii.greatbigworld.floraandfauna.util.FloraAndFaunaTags;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.biome.v1.BiomeModifications;
import net.fabricmc.fabric.api.biome.v1.BiomeSelectors;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricEntityTypeBuilder;
import net.minecraft.class_1299;
import net.minecraft.class_1311;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_4048;
import net.minecraft.class_7923;

public final class FloraAndFaunaEntities {
    public static final class_1299<DuckEntity> DUCK = FabricEntityTypeBuilder.create(class_1311.field_6294).dimensions(class_4048.method_18384(.4f, .85f)).trackRangeChunks(10).entityFactory(DuckEntity::new).build();

    public static void register() {
        class_2378.method_10230(class_7923.field_41177, new class_2960(FloraAndFauna.NAMESPACE, "duck"), DUCK);
        registerAttributes();
        registerSpawns();
    }

    private static void registerAttributes() {
        FabricDefaultAttributeRegistry.register(DUCK, DuckEntity.createDuckAttributes());
    }

    private static void registerSpawns() {
        BiomeModifications.addSpawn(BiomeSelectors.tag(FloraAndFaunaTags.DUCK_SPAWN_BIOMES), class_1311.field_6294, DUCK, 1, 2, 5);
    }

    @Environment(EnvType.CLIENT)
    public static void registerClient() {
        EntityRendererRegistry.register(DUCK, DuckEntityRenderer::new);
        FloraAndFaunaEntityModelLayers.register();
    }
}
