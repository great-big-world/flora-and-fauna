package dev.creoii.greatbigworld.floraandfauna.registry;

import net.fabricmc.fabric.api.gamerule.v1.GameRuleFactory;
import net.fabricmc.fabric.api.gamerule.v1.GameRuleRegistry;
import net.minecraft.class_1928;

public final class FloraAndFaunaGameRules {
    public static class_1928.class_4313<class_1928.class_4310> DO_SEASON_CYCLE;
    public static class_1928.class_4313<class_1928.class_4312> SEASON_LENGTH;

    public static void register() {
        DO_SEASON_CYCLE = GameRuleRegistry.register("doSeasonCycle", class_1928.class_5198.field_24098, GameRuleFactory.createBooleanRule(true));
        SEASON_LENGTH = GameRuleRegistry.register("seasonLength", class_1928.class_5198.field_24098, GameRuleFactory.createIntRule(864000 /* 12 hours */, 100));
    }
}
