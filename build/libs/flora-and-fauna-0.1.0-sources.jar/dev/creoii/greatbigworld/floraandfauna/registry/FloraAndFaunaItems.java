package dev.creoii.greatbigworld.floraandfauna.registry;

import com.mojang.serialization.Lifecycle;
import dev.creoii.creoapi.api.item.CreoItemSettings;
import dev.creoii.greatbigworld.floraandfauna.FloraAndFauna;
import dev.creoii.greatbigworld.floraandfauna.util.ColorHelper;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.rendering.v1.ColorProviderRegistry;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1826;
import net.minecraft.class_1841;
import net.minecraft.class_1933;
import net.minecraft.class_2348;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7706;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import net.minecraft.item.*;
import net.minecraft.registry.*;
import java.util.List;

public final class FloraAndFaunaItems {
    public static final class_1792 HUMUS = new class_1747(FloraAndFaunaBlocks.HUMUS, new CreoItemSettings());
    public static final class_1792 MOSS_CARPET = new class_1747(FloraAndFaunaBlocks.MOSS_CARPET, new CreoItemSettings());
    public static final class_1792 TROPICAL_FERN = new class_1747(FloraAndFaunaBlocks.TROPICAL_FERN, new CreoItemSettings());
    public static final class_1792 LARGE_TROPICAL_FERN = new class_1747(FloraAndFaunaBlocks.LARGE_TROPICAL_FERN, new CreoItemSettings());
    public static final class_1792 RED_HIBISCUS = new class_1747(FloraAndFaunaBlocks.RED_HIBISCUS, new CreoItemSettings());
    public static final class_1792 ORANGE_HIBISCUS = new class_1747(FloraAndFaunaBlocks.ORANGE_HIBISCUS, new CreoItemSettings());
    public static final class_1792 YELLOW_HIBISCUS = new class_1747(FloraAndFaunaBlocks.YELLOW_HIBISCUS, new CreoItemSettings());
    public static final class_1792 BLUE_HIBISCUS = new class_1747(FloraAndFaunaBlocks.BLUE_HIBISCUS, new CreoItemSettings());
    public static final class_1792 PINK_HIBISCUS = new class_1747(FloraAndFaunaBlocks.PINK_HIBISCUS, new CreoItemSettings());
    public static final class_1792 PURPLE_HIBISCUS = new class_1747(FloraAndFaunaBlocks.PURPLE_HIBISCUS, new CreoItemSettings());
    public static final class_1792 BLACK_HIBISCUS = new class_1747(FloraAndFaunaBlocks.BLACK_HIBISCUS, new CreoItemSettings());
    public static final class_1792 WHITE_HIBISCUS = new class_1747(FloraAndFaunaBlocks.WHITE_HIBISCUS, new CreoItemSettings());
    public static final class_1792 HOLLOW_OAK_LOG = new class_1747(FloraAndFaunaBlocks.HOLLOW_OAK_LOG, new CreoItemSettings());
    public static final class_1792 HOLLOW_SPRUCE_LOG = new class_1747(FloraAndFaunaBlocks.HOLLOW_SPRUCE_LOG, new CreoItemSettings());
    public static final class_1792 HOLLOW_BIRCH_LOG = new class_1747(FloraAndFaunaBlocks.HOLLOW_BIRCH_LOG, new CreoItemSettings());
    public static final class_1792 HOLLOW_JUNGLE_LOG = new class_1747(FloraAndFaunaBlocks.HOLLOW_JUNGLE_LOG, new CreoItemSettings());
    public static final class_1792 HOLLOW_DARK_OAK_LOG = new class_1747(FloraAndFaunaBlocks.HOLLOW_DARK_OAK_LOG, new CreoItemSettings());
    public static final class_1792 HOLLOW_ACACIA_LOG = new class_1747(FloraAndFaunaBlocks.HOLLOW_ACACIA_LOG, new CreoItemSettings());
    public static final class_1792 HOLLOW_MANGROVE_LOG = new class_1747(FloraAndFaunaBlocks.HOLLOW_MANGROVE_LOG, new CreoItemSettings());
    public static final class_1792 HOLLOW_CHERRY_LOG = new class_1747(FloraAndFaunaBlocks.HOLLOW_CHERRY_LOG, new CreoItemSettings());
    public static final class_1792 HOLLOW_WARPED_STEM = new class_1747(FloraAndFaunaBlocks.HOLLOW_WARPED_STEM, new CreoItemSettings());
    public static final class_1792 HOLLOW_CRIMSON_STEM = new class_1747(FloraAndFaunaBlocks.HOLLOW_CRIMSON_STEM, new CreoItemSettings());
    public static final class_1792 STRIPPED_HOLLOW_OAK_LOG = new class_1747(FloraAndFaunaBlocks.STRIPPED_HOLLOW_OAK_LOG, new CreoItemSettings());
    public static final class_1792 STRIPPED_HOLLOW_SPRUCE_LOG = new class_1747(FloraAndFaunaBlocks.STRIPPED_HOLLOW_SPRUCE_LOG, new CreoItemSettings());
    public static final class_1792 STRIPPED_HOLLOW_BIRCH_LOG = new class_1747(FloraAndFaunaBlocks.STRIPPED_HOLLOW_BIRCH_LOG, new CreoItemSettings());
    public static final class_1792 STRIPPED_HOLLOW_JUNGLE_LOG = new class_1747(FloraAndFaunaBlocks.STRIPPED_HOLLOW_JUNGLE_LOG, new CreoItemSettings());
    public static final class_1792 STRIPPED_HOLLOW_DARK_OAK_LOG = new class_1747(FloraAndFaunaBlocks.STRIPPED_HOLLOW_DARK_OAK_LOG, new CreoItemSettings());
    public static final class_1792 STRIPPED_HOLLOW_ACACIA_LOG = new class_1747(FloraAndFaunaBlocks.STRIPPED_HOLLOW_ACACIA_LOG, new CreoItemSettings());
    public static final class_1792 STRIPPED_HOLLOW_MANGROVE_LOG = new class_1747(FloraAndFaunaBlocks.STRIPPED_HOLLOW_MANGROVE_LOG, new CreoItemSettings());
    public static final class_1792 STRIPPED_HOLLOW_CHERRY_LOG = new class_1747(FloraAndFaunaBlocks.STRIPPED_HOLLOW_CHERRY_LOG, new CreoItemSettings());
    public static final class_1792 STRIPPED_HOLLOW_WARPED_STEM = new class_1747(FloraAndFaunaBlocks.STRIPPED_HOLLOW_WARPED_STEM, new CreoItemSettings());
    public static final class_1792 STRIPPED_HOLLOW_CRIMSON_STEM = new class_1747(FloraAndFaunaBlocks.STRIPPED_HOLLOW_CRIMSON_STEM, new CreoItemSettings());
    public static final class_1792 ALGAE = new class_1841(FloraAndFaunaBlocks.ALGAE, new CreoItemSettings());

    public static final class_1792 DUCK_SPAWN_EGG = new class_1826(FloraAndFaunaEntities.DUCK, 3637554, 16245884, new CreoItemSettings());

    public static void register() {
        final class_2348<class_1792> items = (class_2348<class_1792>) class_7923.field_41178;

        class_2378.method_10230(class_7923.field_41178, new class_2960(FloraAndFauna.NAMESPACE, "humus"), HUMUS);
        items.method_46744(items.method_10206(class_1802.field_28653), class_5321.method_29179(class_7924.field_41197, new class_2960("moss_carpet")), MOSS_CARPET, Lifecycle.stable());
        class_2378.method_10230(class_7923.field_41178, new class_2960(FloraAndFauna.NAMESPACE, "tropical_fern"), TROPICAL_FERN);
        class_2378.method_10230(class_7923.field_41178, new class_2960(FloraAndFauna.NAMESPACE, "large_tropical_fern"), LARGE_TROPICAL_FERN);
        class_2378.method_10230(class_7923.field_41178, new class_2960(FloraAndFauna.NAMESPACE, "red_hibiscus"), RED_HIBISCUS);
        class_2378.method_10230(class_7923.field_41178, new class_2960(FloraAndFauna.NAMESPACE, "orange_hibiscus"), ORANGE_HIBISCUS);
        class_2378.method_10230(class_7923.field_41178, new class_2960(FloraAndFauna.NAMESPACE, "yellow_hibiscus"), YELLOW_HIBISCUS);
        class_2378.method_10230(class_7923.field_41178, new class_2960(FloraAndFauna.NAMESPACE, "blue_hibiscus"), BLUE_HIBISCUS);
        class_2378.method_10230(class_7923.field_41178, new class_2960(FloraAndFauna.NAMESPACE, "pink_hibiscus"), PINK_HIBISCUS);
        class_2378.method_10230(class_7923.field_41178, new class_2960(FloraAndFauna.NAMESPACE, "purple_hibiscus"), PURPLE_HIBISCUS);
        class_2378.method_10230(class_7923.field_41178, new class_2960(FloraAndFauna.NAMESPACE, "black_hibiscus"), BLACK_HIBISCUS);
        class_2378.method_10230(class_7923.field_41178, new class_2960(FloraAndFauna.NAMESPACE, "white_hibiscus"), WHITE_HIBISCUS);
        class_2378.method_10230(class_7923.field_41178, new class_2960(FloraAndFauna.NAMESPACE, "hollow_oak_log"), HOLLOW_OAK_LOG);
        class_2378.method_10230(class_7923.field_41178, new class_2960(FloraAndFauna.NAMESPACE, "hollow_spruce_log"), HOLLOW_SPRUCE_LOG);
        class_2378.method_10230(class_7923.field_41178, new class_2960(FloraAndFauna.NAMESPACE, "hollow_birch_log"), HOLLOW_BIRCH_LOG);
        class_2378.method_10230(class_7923.field_41178, new class_2960(FloraAndFauna.NAMESPACE, "hollow_jungle_log"), HOLLOW_JUNGLE_LOG);
        class_2378.method_10230(class_7923.field_41178, new class_2960(FloraAndFauna.NAMESPACE, "hollow_dark_oak_log"), HOLLOW_DARK_OAK_LOG);
        class_2378.method_10230(class_7923.field_41178, new class_2960(FloraAndFauna.NAMESPACE, "hollow_acacia_log"), HOLLOW_ACACIA_LOG);
        class_2378.method_10230(class_7923.field_41178, new class_2960(FloraAndFauna.NAMESPACE, "hollow_mangrove_log"), HOLLOW_MANGROVE_LOG);
        class_2378.method_10230(class_7923.field_41178, new class_2960(FloraAndFauna.NAMESPACE, "hollow_cherry_log"), HOLLOW_CHERRY_LOG);
        class_2378.method_10230(class_7923.field_41178, new class_2960(FloraAndFauna.NAMESPACE, "hollow_warped_stem"), HOLLOW_WARPED_STEM);
        class_2378.method_10230(class_7923.field_41178, new class_2960(FloraAndFauna.NAMESPACE, "hollow_crimson_stem"), HOLLOW_CRIMSON_STEM);
        class_2378.method_10230(class_7923.field_41178, new class_2960(FloraAndFauna.NAMESPACE, "stripped_hollow_oak_log"), STRIPPED_HOLLOW_OAK_LOG);
        class_2378.method_10230(class_7923.field_41178, new class_2960(FloraAndFauna.NAMESPACE, "stripped_hollow_spruce_log"), STRIPPED_HOLLOW_SPRUCE_LOG);
        class_2378.method_10230(class_7923.field_41178, new class_2960(FloraAndFauna.NAMESPACE, "stripped_hollow_birch_log"), STRIPPED_HOLLOW_BIRCH_LOG);
        class_2378.method_10230(class_7923.field_41178, new class_2960(FloraAndFauna.NAMESPACE, "stripped_hollow_jungle_log"), STRIPPED_HOLLOW_JUNGLE_LOG);
        class_2378.method_10230(class_7923.field_41178, new class_2960(FloraAndFauna.NAMESPACE, "stripped_hollow_dark_oak_log"), STRIPPED_HOLLOW_DARK_OAK_LOG);
        class_2378.method_10230(class_7923.field_41178, new class_2960(FloraAndFauna.NAMESPACE, "stripped_hollow_acacia_log"), STRIPPED_HOLLOW_ACACIA_LOG);
        class_2378.method_10230(class_7923.field_41178, new class_2960(FloraAndFauna.NAMESPACE, "stripped_hollow_mangrove_log"), STRIPPED_HOLLOW_MANGROVE_LOG);
        class_2378.method_10230(class_7923.field_41178, new class_2960(FloraAndFauna.NAMESPACE, "stripped_hollow_cherry_log"), STRIPPED_HOLLOW_CHERRY_LOG);
        class_2378.method_10230(class_7923.field_41178, new class_2960(FloraAndFauna.NAMESPACE, "stripped_hollow_warped_stem"), STRIPPED_HOLLOW_WARPED_STEM);
        class_2378.method_10230(class_7923.field_41178, new class_2960(FloraAndFauna.NAMESPACE, "stripped_hollow_crimson_stem"), STRIPPED_HOLLOW_CRIMSON_STEM);
        class_2378.method_10230(class_7923.field_41178, new class_2960(FloraAndFauna.NAMESPACE, "algae"), ALGAE);

        class_2378.method_10230(class_7923.field_41178, new class_2960(FloraAndFauna.NAMESPACE, "duck_spawn_egg"), DUCK_SPAWN_EGG);

        ItemGroupEvents.modifyEntriesEvent(class_7706.field_40743).register(entries -> {
            entries.addAfter(class_1802.field_8382, HUMUS);
            entries.addAfter(class_1802.field_8471, TROPICAL_FERN);
            entries.addAfter(class_1802.field_8561, LARGE_TROPICAL_FERN);
            entries.addAfter(class_1802.field_17514, RED_HIBISCUS, ORANGE_HIBISCUS, YELLOW_HIBISCUS, BLUE_HIBISCUS, PINK_HIBISCUS, PURPLE_HIBISCUS, BLACK_HIBISCUS, WHITE_HIBISCUS);
            entries.addAfter(class_1802.field_8583, HOLLOW_OAK_LOG, STRIPPED_HOLLOW_OAK_LOG);
            entries.addAfter(class_1802.field_8684, HOLLOW_SPRUCE_LOG, STRIPPED_HOLLOW_SPRUCE_LOG);
            entries.addAfter(class_1802.field_8170, HOLLOW_BIRCH_LOG, STRIPPED_HOLLOW_BIRCH_LOG);
            entries.addAfter(class_1802.field_8125, HOLLOW_JUNGLE_LOG, STRIPPED_HOLLOW_JUNGLE_LOG);
            entries.addAfter(class_1802.field_8652, HOLLOW_DARK_OAK_LOG, STRIPPED_HOLLOW_DARK_OAK_LOG);
            entries.addAfter(class_1802.field_8820, HOLLOW_ACACIA_LOG, STRIPPED_HOLLOW_ACACIA_LOG);
            entries.addAfter(class_1802.field_37512, HOLLOW_MANGROVE_LOG, STRIPPED_HOLLOW_MANGROVE_LOG);
            entries.addAfter(class_1802.field_42692, HOLLOW_CHERRY_LOG, STRIPPED_HOLLOW_CHERRY_LOG);
            entries.addAfter(class_1802.field_21982, HOLLOW_WARPED_STEM, STRIPPED_HOLLOW_WARPED_STEM);
            entries.addAfter(class_1802.field_21981, HOLLOW_CRIMSON_STEM, STRIPPED_HOLLOW_CRIMSON_STEM);
            entries.addAfter(class_1802.field_17524, ALGAE);
            replaceMossCarpet(entries.getSearchTabStacks());
            replaceMossCarpet(entries.getDisplayStacks());
        });
        ItemGroupEvents.modifyEntriesEvent(class_7706.field_40205).register(entries -> {
            entries.addAfter(class_1802.field_8083, DUCK_SPAWN_EGG);
        });
    }

    private static void replaceMossCarpet(List<class_1799> stacks) {
        stacks.replaceAll(stack -> {
            if (stack.method_31574(class_1802.field_28653))
                return MOSS_CARPET.method_7854();
            return stack;
        });
    }

    @Environment(EnvType.CLIENT)
    public static void registerClient() {
        ColorProviderRegistry.ITEM.register((stack, tintIndex) -> {
            return ColorHelper.add(class_1933.method_8377(.5d, 1d), 50, 50, 0);
        }, TROPICAL_FERN, LARGE_TROPICAL_FERN);
        ColorProviderRegistry.ITEM.register((stack, tintIndex) -> {
            return ColorHelper.add(ColorProviderRegistry.ITEM.get(class_1802.field_8602).getColor(stack, tintIndex), 50, 50, 0);
        }, TROPICAL_FERN, LARGE_TROPICAL_FERN);
    }
}
