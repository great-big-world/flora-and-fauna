package dev.creoii.greatbigworld.floraandfauna.registry;

import dev.creoii.greatbigworld.floraandfauna.FloraAndFauna;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3414;
import net.minecraft.class_7923;

public final class FloraAndFaunaSoundEvents {
    public static final class_3414 ENTITY_DUCK_QUACK = class_3414.method_47908(new class_2960(FloraAndFauna.NAMESPACE, "entity.duck.quack"));

    public static void register() {
        class_2378.method_10230(class_7923.field_41172, new class_2960(FloraAndFauna.NAMESPACE, "entity.duck.quack"), ENTITY_DUCK_QUACK);
    }
}
