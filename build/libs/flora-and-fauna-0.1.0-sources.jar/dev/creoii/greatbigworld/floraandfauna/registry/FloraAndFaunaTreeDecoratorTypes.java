package dev.creoii.greatbigworld.floraandfauna.registry;

import dev.creoii.greatbigworld.floraandfauna.FloraAndFauna;
import dev.creoii.greatbigworld.floraandfauna.world.decorator.BranchTreeDecorator;
import dev.creoii.greatbigworld.floraandfauna.world.decorator.MossTreeDecorator;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_4663;
import net.minecraft.class_7923;

public final class FloraAndFaunaTreeDecoratorTypes {
    public static final class_4663<BranchTreeDecorator> BRANCH = new class_4663<>(BranchTreeDecorator.CODEC);
    public static final class_4663<MossTreeDecorator> MOSS = new class_4663<>(MossTreeDecorator.CODEC);

    public static void register() {
        class_2378.method_10230(class_7923.field_41153, new class_2960(FloraAndFauna.NAMESPACE, "branch"), BRANCH);
        class_2378.method_10230(class_7923.field_41153, new class_2960(FloraAndFauna.NAMESPACE, "moss"), MOSS);
    }
}
