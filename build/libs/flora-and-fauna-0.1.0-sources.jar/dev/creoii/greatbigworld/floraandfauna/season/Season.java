package dev.creoii.greatbigworld.floraandfauna.season;

import dev.creoii.greatbigworld.floraandfauna.util.ColorHelper;
import dev.creoii.greatbigworld.floraandfauna.util.FloraAndFaunaTags;
import java.util.function.Function;
import net.minecraft.class_1920;
import net.minecraft.class_1959;
import net.minecraft.class_2338;
import net.minecraft.class_6880;

public enum Season {
    AUTUMN(Season::applyAutumnColorChange),
    WINTER(Season::applyWinterColorChange),
    SPRING(Season::applySpringColorChange),
    SUMMER(Season::applySummerColorChange);

    private final Function<Context, Integer> colorChange;

    Season(Function<Context, Integer> colorChange) {
        this.colorChange = colorChange;
    }

    public Function<Context, Integer> getColorChange() {
        return colorChange;
    }

    private static int applyAutumnColorChange(Context context) {
        class_6880<class_1959> biomeEntry = context.world.getBiomeFabric(context.pos);

        if (biomeEntry == null || !biomeEntry.method_40227() || biomeEntry.method_40220(FloraAndFaunaTags.NOT_AFFECTED_BY_AUTUMN)) {
            return context.defaultColor;
        }

        return ColorHelper.add(context.defaultColor, 100, 0, 0);
    }

    private static int applyWinterColorChange(Context context) {
        class_6880<class_1959> biomeEntry = context.world.getBiomeFabric(context.pos);

        if (biomeEntry == null || !biomeEntry.method_40227() || biomeEntry.method_40220(FloraAndFaunaTags.NOT_AFFECTED_BY_WINTER)) {
            return context.defaultColor;
        }

        return ColorHelper.add(context.defaultColor, 100, 100, 100);
    }

    private static int applySpringColorChange(Context context) {
        class_6880<class_1959> biomeEntry = context.world.getBiomeFabric(context.pos);

        if (biomeEntry == null || !biomeEntry.method_40227() || biomeEntry.method_40220(FloraAndFaunaTags.NOT_AFFECTED_BY_SPRING)) {
            return context.defaultColor;
        }

        return ColorHelper.add(context.defaultColor, 10, 100, 0);
    }

    private static int applySummerColorChange(Context context) {
        return context.defaultColor;
    }

    public record Context(class_1920 world, class_2338 pos, int defaultColor) {}
}
