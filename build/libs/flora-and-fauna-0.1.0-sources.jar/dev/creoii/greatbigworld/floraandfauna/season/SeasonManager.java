package dev.creoii.greatbigworld.floraandfauna.season;

import dev.creoii.greatbigworld.floraandfauna.FloraAndFauna;
import dev.creoii.greatbigworld.floraandfauna.registry.FloraAndFaunaGameRules;
import dev.creoii.greatbigworld.floraandfauna.util.ColorHelper;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_18;
import net.minecraft.class_1920;
import net.minecraft.class_1937;
import net.minecraft.class_1959;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2540;
import net.minecraft.class_26;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_6880;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.*;

public class SeasonManager extends class_18 {
    public static final class_2960 SYNC_SEASON = new class_2960(FloraAndFauna.NAMESPACE, "sync_season");
    public static final class_2960 SYNC_SEASON_COLOR = new class_2960(FloraAndFauna.NAMESPACE, "sync_season_color");
    private static final class_8645<SeasonManager> STATE_TYPE = new class_8645<>(SeasonManager::new, SeasonManager::createFromNbt, null);
    private static SeasonManager instance;
    private Season currentSeason = Season.SUMMER;
    private static int syncSeasonTime;
    private static int syncSeasonColorTime;
    private static int syncSeasonColorTimeLength;
    private int seasonTime = -1;
    private int seasonColorTime = -1;

    public static SeasonManager getInstance(MinecraftServer server) {
        return instance == null ? instance = getServerState(server) : instance;
    }

    public void setCurrentSeason(class_3218 world, Season season, boolean preserveTime) {
        instance.currentSeason = season;
        if (!preserveTime) {
            instance.seasonTime = 0;
            instance.seasonColorTime = 0;
        }
        load(world);
    }

    public Season getCurrentSeason() {
        return currentSeason;
    }

    public static Season getNextSeason(Season season) {
        return switch (season) {
            case AUTUMN -> Season.WINTER;
            case WINTER -> Season.SPRING;
            case SPRING -> Season.SUMMER;
            case SUMMER -> Season.AUTUMN;
        };
    }

    public static int getColor(class_1920 world, class_2338 pos, int color) {
        if (world == null)
            return color;

        Season.Context context = new Season.Context(world, pos, color);
        class_6880<class_1959> biomeEntry = world.getBiomeFabric(pos);
        if (biomeEntry == null || !biomeEntry.method_40227()) {
            return color;
        }

        return ColorHelper.interpolate(instance.getSeasonColorPercentage(), instance.currentSeason.getColorChange().apply(context), getNextSeason(instance.currentSeason).getColorChange().apply(context));
    }

    public void load(class_3218 world) {
        instance.syncSeason(world.method_8503());
        instance.updateSeasonTime(world);
        instance.syncSeasonColor(world.method_8503());
    }

    public void tick(class_3218 world) {
        MinecraftServer server = world.method_8503();
        if (instance == null) {
            instance = getServerState(server);

            if (instance.currentSeason == null) {
                instance.currentSeason = Season.SUMMER;
            }
            if (instance.seasonTime == -1) {
                instance.seasonTime = 0;
            }
            if (instance.seasonColorTime == -1) {
                instance.seasonColorTime = 0;
            }
            load(world);
        }

        if (world.method_27983() == class_1937.field_25179 && world.method_8450().method_8355(FloraAndFaunaGameRules.DO_SEASON_CYCLE)) {
            // season transition
            if (++instance.seasonTime >= syncSeasonTime) {
                instance.currentSeason = getNextSeason(instance.currentSeason);
                instance.syncSeason(server);
                instance.seasonTime = 0;
                instance.seasonColorTime = 0;
            }

            if (syncSeasonTime != world.method_8450().method_8356(FloraAndFaunaGameRules.SEASON_LENGTH))
                instance.updateSeasonTime(world);

            // color transition
            if (instance.seasonTime >= syncSeasonColorTimeLength && instance.seasonTime < syncSeasonColorTimeLength * 2) {
                if (++instance.seasonColorTime % syncSeasonColorTime == 0) {
                    syncSeasonColor(server);
                }
            }
        }
    }

    private void updateSeasonTime(class_3218 world) {
        syncSeasonTime = world.method_8450().method_8356(FloraAndFaunaGameRules.SEASON_LENGTH);
        syncSeasonColorTimeLength = syncSeasonTime / 3;
        syncSeasonColorTime = syncSeasonColorTimeLength / 30;
    }

    private float getSeasonColorPercentage() {
        return (float) instance.seasonColorTime / syncSeasonColorTimeLength;
    }

    @Override
    public class_2487 method_75(class_2487 nbt) {
        nbt.method_10569("season", instance.currentSeason.ordinal());
        nbt.method_10569("season_time", instance.seasonTime);
        nbt.method_10569("season_color_time", instance.seasonColorTime);
        return nbt;
    }

    private static SeasonManager createFromNbt(class_2487 nbt) {
        SeasonManager manager = new SeasonManager();
        manager.currentSeason = Season.values()[nbt.method_10550("season")];
        manager.seasonTime = nbt.method_10550("season_time");
        manager.seasonColorTime = nbt.method_10550("season_color_time");
        return manager;
    }

    private class_2540 getSyncData() {
        class_2540 buf = PacketByteBufs.create();
        buf.method_53002(instance.currentSeason.ordinal());
        return buf;
    }

    private void syncSeason(MinecraftServer server) {
        server.execute(() -> {
            server.method_3760().method_14571().forEach(serverPlayer -> {
                ServerPlayNetworking.send(serverPlayer, SYNC_SEASON, instance.getSyncData());
            });
        });
    }

    private void syncSeasonColor(MinecraftServer server) {
        server.execute(() -> {
            server.method_3760().method_14571().forEach(serverPlayer -> {
                ServerPlayNetworking.send(serverPlayer, SYNC_SEASON_COLOR, PacketByteBufs.empty());
            });
        });
    }

    private static SeasonManager getServerState(MinecraftServer server) {
        class_26 persistentStateManager = server.method_3847(class_1937.field_25179).method_17983();
        SeasonManager manager = persistentStateManager.method_17924(STATE_TYPE, FloraAndFauna.NAMESPACE);
        manager.method_80();
        return manager;
    }
}
