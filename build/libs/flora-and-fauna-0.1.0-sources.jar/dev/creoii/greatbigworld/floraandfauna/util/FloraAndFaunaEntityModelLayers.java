package dev.creoii.greatbigworld.floraandfauna.util;

import dev.creoii.greatbigworld.floraandfauna.FloraAndFauna;
import dev.creoii.greatbigworld.floraandfauna.client.model.DuckEntityModel;
import net.fabricmc.fabric.api.client.rendering.v1.EntityModelLayerRegistry;
import net.minecraft.class_2960;
import net.minecraft.class_5601;

public final class FloraAndFaunaEntityModelLayers {
    public static final class_5601 DUCK = new class_5601(new class_2960(FloraAndFauna.NAMESPACE, "duck"), "main");

    public static void register() {
        EntityModelLayerRegistry.registerModelLayer(DUCK, DuckEntityModel::getTexturedModelData);
    }
}
