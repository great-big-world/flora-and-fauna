package dev.creoii.greatbigworld.floraandfauna.util;

import dev.creoii.greatbigworld.floraandfauna.FloraAndFauna;
import net.minecraft.class_1299;
import net.minecraft.class_1959;
import net.minecraft.class_2248;
import net.minecraft.class_2960;
import net.minecraft.class_6862;
import net.minecraft.class_7924;
import net.minecraft.class_8110;

public final class FloraAndFaunaTags {
    public static final class_6862<class_2248> IGNORE_SEASON_COLOR = class_6862.method_40092(class_7924.field_41254, new class_2960(FloraAndFauna.NAMESPACE, "ignore_season_color"));
    public static final class_6862<class_2248> HOLLOW_LOGS = class_6862.method_40092(class_7924.field_41254, new class_2960(FloraAndFauna.NAMESPACE, "hollow_logs"));
    public static final class_6862<class_2248> DOES_NOT_SUPPORT_FALLEN_TREES = class_6862.method_40092(class_7924.field_41254, new class_2960(FloraAndFauna.NAMESPACE, "does_not_support_fallen_trees"));

    public static final class_6862<class_1959> NOT_AFFECTED_BY_AUTUMN = class_6862.method_40092(class_7924.field_41236, new class_2960(FloraAndFauna.NAMESPACE, "not_affected_by_autumn"));
    public static final class_6862<class_1959> NOT_AFFECTED_BY_WINTER = class_6862.method_40092(class_7924.field_41236, new class_2960(FloraAndFauna.NAMESPACE, "not_affected_by_winter"));
    public static final class_6862<class_1959> NOT_AFFECTED_BY_SPRING = class_6862.method_40092(class_7924.field_41236, new class_2960(FloraAndFauna.NAMESPACE, "not_affected_by_spring"));
    public static final class_6862<class_1959> NOT_AFFECTED_BY_SUMMER = class_6862.method_40092(class_7924.field_41236, new class_2960(FloraAndFauna.NAMESPACE, "not_affected_by_summer"));
    public static final class_6862<class_1959> DUCK_SPAWN_BIOMES = class_6862.method_40092(class_7924.field_41236, new class_2960(FloraAndFauna.NAMESPACE, "duck_spawn_biomes"));

    public static final class_6862<class_1299<?>> IGNORES_ALGAE = class_6862.method_40092(class_7924.field_41266, new class_2960(FloraAndFauna.NAMESPACE, "ignores_algae"));

    public static final class_6862<class_8110> ALERTS_ANIMALS = class_6862.method_40092(class_7924.field_42534, new class_2960(FloraAndFauna.NAMESPACE, "alerts_animals"));
}
