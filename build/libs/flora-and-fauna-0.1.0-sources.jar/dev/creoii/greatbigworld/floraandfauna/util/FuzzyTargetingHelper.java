package dev.creoii.greatbigworld.floraandfauna.util;

import org.jetbrains.annotations.Nullable;

import java.util.Objects;
import java.util.function.ToDoubleFunction;
import net.minecraft.class_1314;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_5493;
import net.minecraft.class_5534;
import net.minecraft.class_5535;

public final class FuzzyTargetingHelper {
    @Nullable
    public static class_243 findIgnoreWater(class_1314 entity, int horizontalRange, int verticalRange) {
        Objects.requireNonNull(entity);
        return findIgnoreWater(entity, horizontalRange, verticalRange, entity::method_6149);
    }

    @Nullable
    public static class_243 findIgnoreWater(class_1314 entity, int horizontalRange, int verticalRange, ToDoubleFunction<class_2338> scorer) {
        boolean bl = class_5493.method_31517(entity, horizontalRange);
        return class_5535.method_31543(() -> {
            class_2338 blockPos = class_5535.method_31541(entity.method_6051(), horizontalRange, verticalRange);
            class_2338 blockPos2 = class_5534.method_31532(entity, horizontalRange, bl, blockPos);
            return blockPos2 == null ? null : validateIgnoreWater(entity, blockPos2);
        }, scorer);
    }

    @Nullable
    public static class_2338 validateIgnoreWater(class_1314 entity, class_2338 pos) {
        pos = class_5535.method_31540(pos, entity.method_37908().method_31600(), currentPos -> class_5493.method_31523(entity, currentPos) || class_5493.method_31518(entity, currentPos));
        return !class_5493.method_31522(entity, pos) ? pos : null;
    }
}
