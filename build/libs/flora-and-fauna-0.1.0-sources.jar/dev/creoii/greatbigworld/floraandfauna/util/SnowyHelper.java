package dev.creoii.greatbigworld.floraandfauna.util;

import net.minecraft.class_2248;
import net.minecraft.class_259;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2758;

public final class SnowyHelper {
    public static final class_2758 SNOW_LAYERS = class_2758.method_11867("snow_layers", 0, 8);
    public static final class_265[] LAYERS_TO_SHAPE = new class_265[]{class_259.method_1073(), class_2248.method_9541(0.0, 0.0, 0.0, 16.0, 2.0, 16.0), class_2248.method_9541(0.0, 0.0, 0.0, 16.0, 4.0, 16.0), class_2248.method_9541(0.0, 0.0, 0.0, 16.0, 6.0, 16.0), class_2248.method_9541(0.0, 0.0, 0.0, 16.0, 8.0, 16.0), class_2248.method_9541(0.0, 0.0, 0.0, 16.0, 10.0, 16.0), class_2248.method_9541(0.0, 0.0, 0.0, 16.0, 12.0, 16.0), class_2248.method_9541(0.0, 0.0, 0.0, 16.0, 14.0, 16.0), class_2248.method_9541(0.0, 0.0, 0.0, 16.0, 16.0, 16.0)};

    public static boolean isSnowy(class_2680 state) {
        return state.method_28498(SNOW_LAYERS) && state.method_11654(SNOW_LAYERS) > 0;
    }

    public static class_265 getSnowShape(class_2680 state) {
        return LAYERS_TO_SHAPE[state.method_11654(SNOW_LAYERS)];
    }
}
