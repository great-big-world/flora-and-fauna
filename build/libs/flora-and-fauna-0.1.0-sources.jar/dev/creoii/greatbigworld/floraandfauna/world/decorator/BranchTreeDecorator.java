package dev.creoii.greatbigworld.floraandfauna.world.decorator;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import dev.creoii.greatbigworld.floraandfauna.registry.FloraAndFaunaTreeDecoratorTypes;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_3746;
import net.minecraft.class_4651;
import net.minecraft.class_4662;
import net.minecraft.class_4663;
import net.minecraft.class_6017;
import org.apache.commons.lang3.mutable.MutableInt;

public class BranchTreeDecorator extends class_4662 {
    public static final Codec<BranchTreeDecorator> CODEC = RecordCodecBuilder.create((instance) -> {
        return instance.group(class_4651.field_24937.fieldOf("branch_provider").forGetter(config -> {
            return config.branchProvider;
        }), class_6017.field_33450.fieldOf("branch_count").forGetter(config -> {
            return config.branchCount;
        }), Codec.INT.fieldOf("min_height").orElse(5).forGetter(config -> {
            return config.minHeight;
        })).apply(instance, BranchTreeDecorator::new);
    });
    private final class_4651 branchProvider;
    private final class_6017 branchCount;
    private final int minHeight;

    public BranchTreeDecorator(class_4651 state, class_6017 branchCount, int minHeight) {
        this.branchProvider = state;
        this.branchCount = branchCount;
        this.minHeight = Math.max(0, minHeight);
    }

    @Override
    protected class_4663<?> method_28893() {
        return FloraAndFaunaTreeDecoratorTypes.BRANCH;
    }

    @Override
    public void method_23469(class_7402 generator) {
        MutableInt branches = new MutableInt(branchCount.method_35008(generator.method_43320()));
        class_3746 world = generator.method_43316();
        generator.method_43321().sort((logPos1, logPos2) -> {
            if (logPos1.method_10264() == logPos2.method_10264())
                return 0;
            return logPos1.method_10264() - logPos2.method_10264();
        });
        for (int i = 0; i < generator.method_43321().size(); ++i) {
            class_2338 pos = generator.method_43321().get(i);
            class_2350 direction = class_2350.class_2353.field_11062.method_10183(generator.method_43320());
            class_2338 offset = pos.method_10093(direction);
            if (isValidPosition(world, offset, minHeight, generator.method_43321().get(0).method_10264()) && generator.method_43320().method_43057() <= .4f) {
                if (world.method_16358(offset.method_10093(direction), state -> state.method_26215() || state.method_45474())) {
                    class_2680 state = branchProvider.method_23455(generator.method_43320(), offset);

                    if (state.method_28498(class_2741.field_12496)) {
                        state = state.method_11657(class_2741.field_12496, direction.method_10166());
                    } else if (state.method_28498(class_2741.field_12525)) {
                        state = state.method_11657(class_2741.field_12525, direction);
                    } else if (state.method_28498(class_2741.field_12529) && direction.method_10166().method_10179()) {
                        state = state.method_11657(class_2741.field_12529, direction.method_10166());
                    } else if (state.method_28498(class_2741.field_12481) && direction.method_10166().method_10179()) {
                        state = state.method_11657(class_2741.field_12481, direction);
                    } else if (state.method_28498(class_2741.field_12489) && direction == class_2350.field_11043) {
                        state = state.method_11657(class_2741.field_12489, true);
                    } else if (state.method_28498(class_2741.field_12540) && direction == class_2350.field_11035) {
                        state = state.method_11657(class_2741.field_12540, true);
                    } else if (state.method_28498(class_2741.field_12487) && direction == class_2350.field_11034) {
                        state = state.method_11657(class_2741.field_12487, true);
                    } else if (state.method_28498(class_2741.field_12527) && direction == class_2350.field_11039) {
                        state = state.method_11657(class_2741.field_12527, true);
                    } else if (state.method_28498(class_2741.field_12519) && direction == class_2350.field_11036) {
                        state = state.method_11657(class_2741.field_12519, true);
                    } else if (state.method_28498(class_2741.field_12546) && direction == class_2350.field_11033) {
                        state = state.method_11657(class_2741.field_12546, true);
                    }

                    branches.decrement();
                    generator.method_43318(offset, state);

                    if (branches.getValue() <= 0)
                        break;
                }
            }
        }
    }

    private boolean isValidPosition(class_3746 world, class_2338 pos, int minHeight, int bottomY) {
        int distance = pos.method_10264() - bottomY;
        if (distance >= Math.max(0, minHeight)) {
            return world.method_16358(pos, state -> state.method_26215() || state.method_45474());
        }

        return false;
    }
}
