package dev.creoii.greatbigworld.floraandfauna.world.decorator;

import com.mojang.serialization.Codec;
import dev.creoii.greatbigworld.floraandfauna.registry.FloraAndFaunaBlocks;
import dev.creoii.greatbigworld.floraandfauna.registry.FloraAndFaunaTreeDecoratorTypes;
import dev.creoii.greatbigworld.floraandfauna.util.SnowyHelper;
import net.minecraft.block.*;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2429;
import net.minecraft.class_2680;
import net.minecraft.class_2746;
import net.minecraft.class_3746;
import net.minecraft.class_4662;
import net.minecraft.class_4663;
import net.minecraft.class_5819;
import org.apache.commons.lang3.mutable.MutableInt;

public class MossTreeDecorator extends class_4662 {
    public static final Codec<MossTreeDecorator> CODEC = Codec.floatRange(0f, 1f).fieldOf("probability").xmap(MossTreeDecorator::new, decorator -> decorator.probability).codec();
    private final float probability;

    public MossTreeDecorator(float probability) {
        this.probability = probability;
    }

    @Override
    protected class_4663<?> method_28893() {
        return FloraAndFaunaTreeDecoratorTypes.MOSS;
    }

    @Override
    public void method_23469(class_4662.class_7402 generator) {
        class_5819 random = generator.method_43320();
        MutableInt noise = new MutableInt(random.method_43048(5) - 2);
        MutableInt noiseProbability = new MutableInt();
        class_3746 world = generator.method_43316();
        for (class_2338 pos : generator.method_43321()) {
            if (random.method_43057() > probability)
                continue;

            class_2338 blockPos;
            noiseProbability.setValue(random.method_43048(3) - 1);
            if (noise.getValue() > 0) {
                blockPos = pos.method_10067();
                if (generator.method_43317(blockPos) || world.method_16358(blockPos, state -> state.method_27852(class_2246.field_10597))) {
                    replaceWithMoss(generator, blockPos, class_2429.field_11335);
                }
            }

            if (noise.getValue() > 0) {
                blockPos = pos.method_10078();
                if (generator.method_43317(blockPos) || world.method_16358(blockPos, state -> state.method_27852(class_2246.field_10597))) {
                    replaceWithMoss(generator, blockPos, class_2429.field_11328);
                }
            }

            if (noise.getValue() > 0) {
                blockPos = pos.method_10095();
                if (generator.method_43317(blockPos) || world.method_16358(blockPos, state -> state.method_27852(class_2246.field_10597))) {
                    replaceWithMoss(generator, blockPos, class_2429.field_11331);
                }
            }

            if (noise.getValue() > 0) {
                blockPos = pos.method_10072();
                if (generator.method_43317(blockPos) || world.method_16358(blockPos, state -> state.method_27852(class_2246.field_10597))) {
                    replaceWithMoss(generator, blockPos, class_2429.field_11332);
                }
            }

            if (noise.getValue() > 0) {
                blockPos = pos.method_10084();
                if (generator.method_43317(blockPos) || world.method_16358(blockPos, state -> state.method_27852(class_2246.field_10597))) {
                    replaceWithMoss(generator, blockPos, class_2429.field_11330);
                }
            }

            if (noise.getValue() > 0) {
                blockPos = pos.method_10074();
                if (generator.method_43317(blockPos) || world.method_16358(blockPos, state -> state.method_27852(class_2246.field_10597))) {
                    replaceWithMoss(generator, blockPos, class_2429.field_11327);
                }
            }

            if (noiseProbability.getValue() < 0) {
                noise.setValue(Math.max(noise.getValue() - 1, -2));
            } else if (noiseProbability.getValue() > 0) {
                noise.setValue(Math.min(noise.getValue() + 1, 2));
            }
        }
    }

    public void replaceWithMoss(class_4662.class_7402 generator, class_2338 pos, class_2746 faceProperty) {
        class_2680 mossState = FloraAndFaunaBlocks.MOSS_CARPET.method_9564();

        class_3746 world = generator.method_43316();
        if (world.method_16358(pos, state -> state == FloraAndFaunaBlocks.MOSS_CARPET.method_9564().method_11657(class_2429.field_11328, true)))
            mossState = mossState.method_11657(class_2429.field_11328, true);
        if (world.method_16358(pos, state -> state == FloraAndFaunaBlocks.MOSS_CARPET.method_9564().method_11657(class_2429.field_11335, true)))
            mossState = mossState.method_11657(class_2429.field_11335, true);
        if (world.method_16358(pos, state -> state == FloraAndFaunaBlocks.MOSS_CARPET.method_9564().method_11657(class_2429.field_11331, true)))
            mossState = mossState.method_11657(class_2429.field_11331, true);
        if (world.method_16358(pos, state -> state == FloraAndFaunaBlocks.MOSS_CARPET.method_9564().method_11657(class_2429.field_11332, true)))
            mossState = mossState.method_11657(class_2429.field_11332, true);
        if (world.method_16358(pos, state -> state == FloraAndFaunaBlocks.MOSS_CARPET.method_9564().method_11657(class_2429.field_11327, true)))
            mossState = mossState.method_11657(class_2429.field_11327, true);
        if (world.method_16358(pos, state -> state == FloraAndFaunaBlocks.MOSS_CARPET.method_9564().method_11657(class_2429.field_11330, true)))
            mossState = mossState.method_11657(class_2429.field_11330, true);

        if (world.method_16358(pos, state -> state.method_27852(class_2246.field_10477)))
            mossState = mossState.method_11657(SnowyHelper.SNOW_LAYERS, 1);

        generator.method_43318(pos, mossState.method_11657(faceProperty, true));
    }
}
