package dev.creoii.greatbigworld.floraandfauna.world.feature;

import com.mojang.serialization.Codec;
import dev.creoii.greatbigworld.floraandfauna.block.MossCarpetBlock;
import dev.creoii.greatbigworld.floraandfauna.registry.FloraAndFaunaBlocks;
import dev.creoii.greatbigworld.floraandfauna.util.FloraAndFaunaTags;
import dev.creoii.greatbigworld.floraandfauna.util.SnowyHelper;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_3031;
import net.minecraft.class_3481;
import net.minecraft.class_5281;
import net.minecraft.class_5821;

public class FallenTreeFeature extends class_3031<FallenTreeFeatureConfig> {
    public FallenTreeFeature(Codec<FallenTreeFeatureConfig> codec) {
        super(codec);
    }

    @Override
    public boolean method_13151(class_5821<FallenTreeFeatureConfig> context) {
        FallenTreeFeatureConfig config = context.method_33656();
        class_5281 world = context.method_33652();
        class_2338 origin = context.method_33655();
        class_2680 state = config.state().method_23455(context.method_33654(), origin);
        int length = config.length().method_35008(context.method_33654());
        float mossChance = config.mossChance().method_35008(context.method_33654()) / 100f;

        class_2350 direction = class_2350.class_2353.field_11062.method_10183(context.method_33654());
        if (state.method_28498(class_2741.field_12496)) {
            state = state.method_11657(class_2741.field_12496, direction.method_10166());
        } else if (state.method_28498(class_2741.field_12529) && direction.method_10166().method_10179()) {
            state = state.method_11657(class_2741.field_12529, direction.method_10166());
        } else if (state.method_28498(class_2741.field_12525)) {
            state = state.method_11657(class_2741.field_12525, direction);
        } else if (state.method_28498(class_2741.field_12481) && direction.method_10166().method_10179()) {
            state = state.method_11657(class_2741.field_12481, direction);
        }

        List<class_2338> placementPositions = new ArrayList<>();
        boolean unstable = false;
        for (int i = 0, j = length / 2; i < length; ++i) {
            class_2338 pos = origin.method_10079(direction, i);
            class_2680 downState = world.method_8320(pos.method_10074());
            if (downState.method_26164(FloraAndFaunaTags.DOES_NOT_SUPPORT_FALLEN_TREES)) {
                --j;
            } else if (j <= 0) {
                j = length / 2;
                unstable = false;
            }

            placementPositions.add(pos);

            class_2680 placeState = world.method_8320(pos);
            if ((!placeState.method_26215() && !placeState.method_45474()) || placeState.method_26164(class_3481.field_33757)) {
                placementPositions.clear();
                break;
            }
            if (j <= 0) {
                unstable = true;
            }
        }

        if (unstable) {
            return false;
        }

        for (class_2338 pos : placementPositions) {
            world.method_8652(pos, state, class_2248.field_31036);

            if (context.method_33654().method_43057() > mossChance)
                continue;

            for (class_2350 direction1 : class_2350.values()) {
                if (direction1.method_10166() == direction.method_10166())
                    continue;

                class_2338 offset = pos.method_10093(direction1);
                class_2680 offsetState = world.method_8320(offset);
                if ((offsetState.method_26215() || offsetState.method_45474()) && !world.method_22351(offset)) {
                    world.method_8652(offset, FloraAndFaunaBlocks.MOSS_CARPET.method_9564().method_11657(MossCarpetBlock.method_33374(direction1.method_10153()), true).method_11657(SnowyHelper.SNOW_LAYERS, world.method_8320(offset).method_27852(class_2246.field_10477) ? 1 : 0), 19);
                }
            }
        }

        return !placementPositions.isEmpty();
    }
}
