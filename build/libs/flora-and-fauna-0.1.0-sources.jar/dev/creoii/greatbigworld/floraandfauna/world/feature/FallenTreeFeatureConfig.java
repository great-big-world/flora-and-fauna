package dev.creoii.greatbigworld.floraandfauna.world.feature;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.class_3037;
import net.minecraft.class_4651;
import net.minecraft.class_6016;
import net.minecraft.class_6017;

public record FallenTreeFeatureConfig(class_4651 state, class_6017 length, class_6017 mossChance) implements class_3037 {
    public static final Codec<FallenTreeFeatureConfig> CODEC = RecordCodecBuilder.create((instance) -> {
        return instance.group(class_4651.field_24937.fieldOf("state").forGetter((config) -> {
            return config.state;
        }), class_6017.method_35004(1, 16).fieldOf("length").forGetter((config) -> {
            return config.length;
        }), class_6017.method_35004(0, 100).fieldOf("moss_chance").orElse(class_6016.method_34998(0)).forGetter((config) -> {
            return config.mossChance;
        })).apply(instance, FallenTreeFeatureConfig::new);
    });
}
