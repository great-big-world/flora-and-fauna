package dev.creoii.greatbigworld.floraandfauna.world.feature;

import com.mojang.serialization.Codec;
import dev.creoii.greatbigworld.floraandfauna.util.SnowyHelper;
import net.minecraft.class_1944;
import net.minecraft.class_1959;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2493;
import net.minecraft.class_2680;
import net.minecraft.class_2902;
import net.minecraft.class_3031;
import net.minecraft.class_3111;
import net.minecraft.class_4538;
import net.minecraft.class_5281;
import net.minecraft.class_5821;

public class FreezeTopLayerFeature extends class_3031<class_3111> {
    public FreezeTopLayerFeature(Codec<class_3111> codec) {
        super(codec);
    }

    @Override
    public boolean method_13151(class_5821<class_3111> context) {
        class_5281 world = context.method_33652();
        class_2338 pos = context.method_33655();
        class_2338.class_2339 top = new class_2338.class_2339();
        class_2338.class_2339 topDown = new class_2338.class_2339();
        class_2338.class_2339 bottom = new class_2338.class_2339();
        class_2338.class_2339 bottomDown = new class_2338.class_2339();
        for (int i = 0; i < 16; ++i) {
            int k = pos.method_10263() + i;
            for (int j = 0; j < 16; ++j) {
                int l = pos.method_10260() + j;
                int m = world.method_8624(class_2902.class_2903.field_13197, k, l);
                int m1 = world.method_8624(class_2902.class_2903.field_13203, k, l);
                top.method_10103(k, m, l);
                topDown.method_10101(top).method_10098(class_2350.field_11033);
                bottom.method_10103(k, m1, l);
                bottomDown.method_10101(bottom).method_10098(class_2350.field_11033);
                class_1959 topBiome = world.method_23753(top).comp_349();
                class_1959 bottomBiome = world.method_23753(bottom).comp_349();

                if (topBiome.method_8685(world, topDown, false)) {
                    world.method_8652(topDown, class_2246.field_10295.method_9564(), class_2248.field_31028);
                }

                if (topBiome.method_8696(world, top)) {
                    class_2680 blockState = world.method_8320(topDown);
                    if (world.method_8652(top, class_2246.field_10477.method_9564(), class_2248.field_31028) && blockState.method_28498(class_2493.field_11522))
                        world.method_8652(topDown, blockState.method_11657(class_2493.field_11522, true), class_2248.field_31028);
                }

                if (canSetSnow(topBiome, world, top)) {
                    class_2680 blockState = world.method_8320(top);
                    if (blockState.method_28498(SnowyHelper.SNOW_LAYERS)) {
                        class_2680 blockState1 = world.method_8320(topDown);
                        if (world.method_8652(top, blockState.method_11657(SnowyHelper.SNOW_LAYERS, 1), class_2248.field_31028) && blockState1.method_28498(class_2493.field_11522))
                            world.method_8652(topDown, blockState1.method_11657(class_2493.field_11522, true), class_2248.field_31028);
                    }
                }

                if (m == m1)
                    continue;

                if (bottomBiome.method_8685(world, bottomDown, false)) {
                    world.method_8652(bottomDown, class_2246.field_10295.method_9564(), class_2248.field_31028);
                }

                if (bottomBiome.method_8696(world, bottom)) {
                    class_2680 blockState = world.method_8320(bottomDown);
                    if (world.method_8652(bottom, class_2246.field_10477.method_9564(), class_2248.field_31028) && blockState.method_28498(class_2493.field_11522))
                        world.method_8652(bottomDown, blockState.method_11657(class_2493.field_11522, true), class_2248.field_31028);
                }

                if (canSetSnow(bottomBiome, world, bottom)) {
                    class_2680 blockState = world.method_8320(bottom);
                    if (blockState.method_28498(SnowyHelper.SNOW_LAYERS)) {
                        class_2680 blockState1 = world.method_8320(bottomDown);
                        if (world.method_8652(bottom, blockState.method_11657(SnowyHelper.SNOW_LAYERS, 1), class_2248.field_31036) && blockState1.method_28498(class_2493.field_11522))
                            world.method_8652(bottomDown, blockState1.method_11657(class_2493.field_11522, true), class_2248.field_31028);
                    }
                }
            }
        }
        return true;
    }

    public boolean canSetSnow(class_1959 biome, class_4538 world, class_2338 pos) {
        if (biome.method_39927(pos)) {
            return false;
        } else return pos.method_10264() >= world.method_31607() && pos.method_10264() < world.method_31600() && world.method_8314(class_1944.field_9282, pos) < 10;
    }
}
