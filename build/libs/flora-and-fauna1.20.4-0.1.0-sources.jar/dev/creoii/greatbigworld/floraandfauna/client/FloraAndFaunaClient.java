package dev.creoii.greatbigworld.floraandfauna.client;

import dev.creoii.greatbigworld.floraandfauna.FloraAndFauna;
import dev.creoii.greatbigworld.floraandfauna.client.compat.SodiumClientCompat;
import dev.creoii.greatbigworld.floraandfauna.registry.FloraAndFaunaBlocks;
import dev.creoii.greatbigworld.floraandfauna.registry.FloraAndFaunaItems;
import dev.creoii.greatbigworld.floraandfauna.season.Season;
import dev.creoii.greatbigworld.floraandfauna.season.SeasonManager;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_846;
import org.apache.logging.log4j.Level;
import org.jetbrains.annotations.Nullable;

public class FloraAndFaunaClient implements ClientModInitializer {
    private static final boolean SODIUM_LOADED = FabricLoader.getInstance().isModLoaded("sodium");
    @Nullable private static Season currentSeason;

    @Override
    public void onInitializeClient() {
        FloraAndFaunaBlocks.registerClient();
        FloraAndFaunaItems.registerClient();

        ClientPlayNetworking.registerGlobalReceiver(SeasonManager.SYNC_SEASON, (client, handler, buf, responseSender) -> {
            Season season = Season.values()[buf.readInt()];
            client.execute(() -> currentSeason = season);
        });

        if (SODIUM_LOADED) {
            FloraAndFauna.LOGGER.log(Level.INFO, "Sodium detected, modifying season sync color rebuilds.");
            SodiumClientCompat.registerSyncSeasonColorReceiver();
        } else {
            ClientPlayNetworking.registerGlobalReceiver(SeasonManager.SYNC_SEASON_COLOR, (client, handler, buf, responseSender) -> {
                client.execute(() -> {
                    if (client.field_1769.field_4112 != null) {
                        for (class_846.class_851 chunk : client.worldRenderer.chunks.chunks) {
                            if (chunk == null)
                                continue;
                            chunk.method_3654(true);
                        }
                    }
                });
            });
        }
    }

    @Nullable
    public static Season getCurrentSeason() {
        return currentSeason;
    }
}
