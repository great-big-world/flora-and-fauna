package dev.creoii.greatbigworld.floraandfauna.mixin.block;

import com.llamalad7.mixinextras.sugar.Local;
import dev.creoii.greatbigworld.floraandfauna.client.FloraAndFaunaClient;
import dev.creoii.greatbigworld.floraandfauna.season.Season;
import dev.creoii.greatbigworld.floraandfauna.util.FloraAndFaunaTags;
import dev.creoii.greatbigworld.floraandfauna.util.SnowyHelper;
import net.minecraft.block.*;
import net.minecraft.class_10;
import net.minecraft.class_1309;
import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_1944;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2261;
import net.minecraft.class_2320;
import net.minecraft.class_2338;
import net.minecraft.class_2488;
import net.minecraft.class_259;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2754;
import net.minecraft.class_2756;
import net.minecraft.class_3218;
import net.minecraft.class_3726;
import net.minecraft.class_5819;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_2320.class)
public abstract class TallPlantBlockMixin extends class_2261 {
    @Shadow @Final public static class_2754<class_2756> HALF;

    protected TallPlantBlockMixin(class_2251 settings) {
        super(settings);
    }

    @Inject(method = "<init>", at = @At("TAIL"))
    private void gbw$setSnowyDefaultState(class_2251 settings, CallbackInfo ci) {
        method_9590(field_10647.method_11664().method_11657(HALF, class_2756.field_12607).method_11657(SnowyHelper.SNOW_LAYERS, 0));
    }

    @Inject(method = "getPlacementState", at = @At("RETURN"), cancellable = true)
    private void gbw$applySnowyPlacementState(class_1750 ctx, CallbackInfoReturnable<class_2680> cir, @Local class_1937 world, @Local class_2338 blockPos) {
        class_2680 state = world.method_8320(blockPos);
        if (cir.getReturnValue().method_11654(HALF) == class_2756.field_12607 && state.method_27852(class_2246.field_10477)) {
            cir.setReturnValue(cir.getReturnValue().method_11657(SnowyHelper.SNOW_LAYERS, state.method_11654(class_2488.field_11518)));
        }
    }

    @Inject(method = "appendProperties", at = @At("TAIL"))
    private void gbw$addSnowyProperty(class_2689.class_2690<class_2248, class_2680> builder, CallbackInfo ci) {
        builder.method_11667(SnowyHelper.SNOW_LAYERS);
    }

    @Inject(method = "onPlaced", at = @At("HEAD"), cancellable = true)
    private void gbw$fixSnowPlacementBug(class_1937 world, class_2338 pos, class_2680 state, class_1309 placer, class_1799 itemStack, CallbackInfo ci) {
        if (SnowyHelper.isSnowy(state)) {
            ci.cancel();
        }
    }

    @Override
    public boolean method_9542(class_2680 state) {
        return SnowyHelper.isSnowy(state);
    }

    @SuppressWarnings("deprecation")
    public void method_9514(class_2680 state, class_3218 world, class_2338 pos, class_5819 random) {
        if (world.method_8314(class_1944.field_9282, pos) > 11 || (FloraAndFaunaClient.getCurrentSeason() != Season.WINTER && !world.method_23753(pos).method_40220(FloraAndFaunaTags.NOT_AFFECTED_BY_WINTER))) {
            if (state.method_11654(SnowyHelper.SNOW_LAYERS) > 0)
                method_9497(class_2246.field_10477.method_9564().method_11657(class_2488.field_11518, state.method_11654(SnowyHelper.SNOW_LAYERS)), world, pos);
            world.method_8501(pos, state.method_11657(SnowyHelper.SNOW_LAYERS, 0));
        }
    }

    public boolean method_9516(class_2680 state, class_1922 world, class_2338 pos, class_10 type) {
        if (type == class_10.field_50)
            return state.method_11654(SnowyHelper.SNOW_LAYERS) < 5;
        return false;
    }

    @SuppressWarnings("deprecation")
    public class_265 method_9549(class_2680 state, class_1922 world, class_2338 pos, class_3726 context) {
        if (SnowyHelper.isSnowy(state)) {
            return SnowyHelper.LAYERS_TO_SHAPE[state.method_11654(SnowyHelper.SNOW_LAYERS) - 1];
        }
        return class_259.method_1073();
    }

    @SuppressWarnings("deprecation")
    public class_265 method_25959(class_2680 state, class_1922 world, class_2338 pos) {
        if (SnowyHelper.isSnowy(state)) {
            return SnowyHelper.getSnowShape(state);
        }
        return class_259.method_1073();
    }

    @SuppressWarnings("deprecation")
    public class_265 method_26159(class_2680 state, class_1922 world, class_2338 pos, class_3726 context) {
        if (SnowyHelper.isSnowy(state)) {
            return SnowyHelper.getSnowShape(state);
        }
        return class_259.method_1073();
    }
}
